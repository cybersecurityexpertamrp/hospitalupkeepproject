<?php
session_start();
include_once "db.php";

if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}

if (!isset($_GET["id"])) {
    die("Complaint ID is missing.");
}

$complaint_id = intval($_GET["id"]);

$sql = "SELECT * FROM complaints WHERE complaint_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $complaint_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Complaint not found.");
}

$complaint = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $work_assigned = $_POST["work_assigned"];
    $action_taken = $_POST["action_taken"];

    $sql = "UPDATE complaints
            SET work_assigned = ?,
                action_taken = ?,
                action_date = NOW(),
                complaint_status = 'Action Started'
            WHERE complaint_id = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssi",
        $work_assigned,
        $action_taken,
        $complaint_id
    );

    if ($stmt->execute()) {

        header("Location: admin_dashboard.php");
        exit();

    } else {

        $error = "Unable to save action.";
    }
}
?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Work Assigned & Action Started</title>

<style>

body {
    font-family: Arial, sans-serif;
    background: #f4f6f9;
    margin: 0;
    padding: 30px;
}

.container {
    max-width: 750px;
    margin: auto;
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

h2 {
    color: #5a2ca0;
    margin-bottom: 25px;
}

.details {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 25px;
}

.details p {
    margin: 8px 0;
}

label {
    display: block;
    margin-top: 15px;
    margin-bottom: 7px;
    font-weight: bold;
}

textarea {
    width: 100%;
    min-height: 120px;
    padding: 12px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 6px;
    resize: vertical;
}

button {
    margin-top: 25px;
    width: 100%;
    padding: 13px;
    background: #6f42c1;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #59339d;
}

.error {
    color: red;
}

</style>

</head>

<body>

<div class="container">

<h2>5. Work Assigned & Action Started</h2>

<div class="details">

<p>
<strong>Complaint ID:</strong>
<?php echo htmlspecialchars($complaint["complaint_id"]); ?>
</p>

<p>
<strong>Department:</strong>
<?php echo htmlspecialchars($complaint["department"]); ?>
</p>

<p>
<strong>Officer:</strong>
<?php echo htmlspecialchars($complaint["officer_name"]); ?>
</p>

<p>
<strong>Designation:</strong>
<?php echo htmlspecialchars($complaint["officer_designation"]); ?>
</p>

<p>
<strong>Contact:</strong>
<?php echo htmlspecialchars($complaint["officer_contact"]); ?>
</p>

</div>

<?php if (isset($error)) { ?>

<p class="error">
<?php echo $error; ?>
</p>

<?php } ?>

<form method="POST">

<label>
Work Assigned
</label>

<textarea
    name="work_assigned"
    placeholder="Describe the work assigned to the concerned officer/department..."
    required
></textarea>

<label>
Action Started / Action Taken
</label>

<textarea
    name="action_taken"
    placeholder="Describe the action started or action taken..."
    required
></textarea>

<button type="submit">
    Start Action
</button>

</form>

</div>

</body>

</html>