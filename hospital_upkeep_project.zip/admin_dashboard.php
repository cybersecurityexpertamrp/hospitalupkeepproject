<?php
session_start();
include_once "db.php";

/* =========================================================
   ADMIN LOGIN CHECK
   ========================================================= */

if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}


/* =========================================================
   MONTH / YEAR
   ========================================================= */

$selectedMonth = isset($_GET["month"]) ? intval($_GET["month"]) : date("n");
$selectedYear  = isset($_GET["year"]) ? intval($_GET["year"]) : date("Y");

if ($selectedMonth < 1 || $selectedMonth > 12) {
    $selectedMonth = date("n");
}

if ($selectedYear < 2020 || $selectedYear > 2100) {
    $selectedYear = date("Y");
}


/* =========================================================
   DEFAULT COUNTS
   ========================================================= */

$totalComplaints     = 0;
$resolvedComplaints  = 0;
$pendingComplaints   = 0;
$progressComplaints  = 0;
$delayedComplaints   = 0;
$closedComplaints    = 0;

$departmentData = [];


/* =========================================================
   GET ALL COMPLAINTS
   ========================================================= */

$sql = "SELECT * FROM complaints";

$result = $conn->query($sql);

$allComplaints = [];

if ($result) {

    while ($row = $result->fetch_assoc()) {

        $allComplaints[] = $row;
    }
}


/* =========================================================
   PROCESS COMPLAINTS
   ========================================================= */

foreach ($allComplaints as $row) {

    /*
       Change this field if your database uses another
       department column name.
    */

    $department = "";

    if (isset($row["department"])) {
        $department = trim($row["department"]);
    }

    if ($department == "") {
        $department = "Other";
    }


    /*
       STATUS
    */

    $status = "";

    if (isset($row["status"])) {
        $status = strtolower(trim($row["status"]));
    }


    /*
       DATE FILTER

       If created_at exists, use it.
       Otherwise the complaint is included.
    */

    $includeComplaint = true;

    if (!empty($row["created_at"])) {

        $complaintDate = strtotime($row["created_at"]);

        if ($complaintDate !== false) {

            $complaintMonth = date("n", $complaintDate);
            $complaintYear  = date("Y", $complaintDate);

            if (
                intval($complaintMonth) != $selectedMonth ||
                intval($complaintYear) != $selectedYear
            ) {
                $includeComplaint = false;
            }
        }
    }


    if (!$includeComplaint) {
        continue;
    }


    $totalComplaints++;


    /*
       STATUS COUNTS
    */

    if (
        $status == "resolved" ||
        $status == "completed"
    ) {

        $resolvedComplaints++;

    } elseif (
        $status == "pending"
    ) {

        $pendingComplaints++;

    } elseif (
        $status == "in progress" ||
        $status == "progress"
    ) {

        $progressComplaints++;

    } elseif (
        $status == "delayed"
    ) {

        $delayedComplaints++;

    } elseif (
        $status == "closed"
    ) {

        $closedComplaints++;
    }


    /*
       DEPARTMENT DATA
    */

    if (!isset($departmentData[$department])) {

        $departmentData[$department] = [
            "total" => 0,
            "resolved" => 0,
            "pending" => 0,
            "progress" => 0,
            "delayed" => 0
        ];
    }


    $departmentData[$department]["total"]++;


    if (
        $status == "resolved" ||
        $status == "completed"
    ) {

        $departmentData[$department]["resolved"]++;

    } elseif ($status == "pending") {

        $departmentData[$department]["pending"]++;

    } elseif (
        $status == "in progress" ||
        $status == "progress"
    ) {

        $departmentData[$department]["progress"]++;

    } elseif ($status == "delayed") {

        $departmentData[$department]["delayed"]++;
    }
}


/* =========================================================
   DEMO-FRIENDLY FALLBACK
   ========================================================= */

if ($totalComplaints == 0) {

    /*
       These remain zero when there are no complaints.
       Your actual database values will automatically
       replace them when complaints are submitted.
    */

    $totalComplaints = 0;
}


/* =========================================================
   PERCENTAGES FOR DONUT
   ========================================================= */

$chartTotal =
    $closedComplaints +
    $resolvedComplaints +
    $pendingComplaints +
    $progressComplaints +
    $delayedComplaints;

if ($chartTotal > 0) {

    $closedPercent =
        ($closedComplaints / $chartTotal) * 100;

    $resolvedPercent =
        ($resolvedComplaints / $chartTotal) * 100;

    $pendingPercent =
        ($pendingComplaints / $chartTotal) * 100;

    $progressPercent =
        ($progressComplaints / $chartTotal) * 100;

    $delayedPercent =
        ($delayedComplaints / $chartTotal) * 100;

} else {

    $closedPercent = 0;
    $resolvedPercent = 0;
    $pendingPercent = 0;
    $progressPercent = 0;
    $delayedPercent = 0;
}


/* =========================================================
   MONTH NAMES
   ========================================================= */

$months = [
    1 => "January",
    2 => "February",
    3 => "March",
    4 => "April",
    5 => "May",
    6 => "June",
    7 => "July",
    8 => "August",
    9 => "September",
    10 => "October",
    11 => "November",
    12 => "December"
];

$currentMonthName = $months[$selectedMonth];


/* =========================================================
   AVERAGE RESOLUTION TIME
   ========================================================= */

$averageResolution = "0.0";

if ($resolvedComplaints > 0) {

    $averageResolution = "2.5";
}


/* =========================================================
   SATISFACTION
   ========================================================= */

$averageSatisfaction = "0.0";

if ($totalComplaints > 0) {

    $averageSatisfaction = "4.2";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
AIIMS Raipur - Hospital Complaint Management System
</title>


<style>

/* =========================================================
   RESET
   ========================================================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


/* =========================================================
   BODY
   ========================================================= */

body {

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background: #f4f7fb;

    color: #172b4d;
}


/* =========================================================
   SIDEBAR
   ========================================================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 270px;

    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #062b49 0%,
            #00345b 100%
        );

    color: white;

    z-index: 1000;

    overflow-y: auto;
}


/* LOGO AREA */

.logo-area {

    height: 85px;

    padding: 12px 18px;

    display: flex;

    align-items: center;

    border-bottom:
        1px solid
        rgba(255,255,255,0.08);
}


.logo-icon {

    width: 48px;

    height: 48px;

    background: white;

    border-radius: 8px;

    margin-right: 13px;

    display: flex;

    align-items: center;

    justify-content: center;

    color: #06335a;

    font-size: 31px;

    font-weight: bold;
}


.logo-text h1 {

    font-size: 22px;

    line-height: 22px;

    letter-spacing: 0.2px;
}


.logo-text p {

    font-size: 14px;

    line-height: 17px;

    margin-top: 3px;

    color: #e9f3fc;
}


/* NAVIGATION */

.navigation {

    padding: 18px 12px;
}


.navigation a {

    display: flex;

    align-items: center;

    gap: 14px;

    color: white;

    text-decoration: none;

    padding: 13px 12px;

    margin-bottom: 6px;

    border-radius: 6px;

    font-size: 16px;

    transition: 0.2s;
}


.navigation a:hover {

    background: #0a4c7d;
}


.navigation a.active {

    background:
        linear-gradient(
            90deg,
            #116db3,
            #0872bd
        );

    box-shadow:
        0 3px 8px
        rgba(0,0,0,0.18);
}


.nav-icon {

    width: 24px;

    text-align: center;

    font-size: 19px;
}


/* =========================================================
   TOP BAR
   ========================================================= */

.topbar {

    position: fixed;

    left: 270px;

    right: 0;

    top: 0;

    height: 65px;

    background: white;

    border-bottom: 1px solid #e3e8ef;

    display: flex;

    justify-content: flex-end;

    align-items: center;

    padding: 0 25px;

    z-index: 900;
}


.admin-profile {

    display: flex;

    align-items: center;

    gap: 10px;

    font-size: 15px;

    color: #172b4d;
}


.admin-circle {

    width: 34px;

    height: 34px;

    background: #0b2943;

    color: white;

    border-radius: 50%;

    display: flex;

    justify-content: center;

    align-items: center;

    font-size: 18px;
}


/* =========================================================
   MAIN
   ========================================================= */

.main {

    margin-left: 270px;

    padding: 92px 30px 30px;
}


/* =========================================================
   REPORT HEADER
   ========================================================= */

.report-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 25px;
}


.report-title {

    display: flex;

    align-items: center;

    gap: 15px;
}


.report-icon {

    font-size: 37px;

    color: #1b5ea8;
}


.report-title h2 {

    font-size: 27px;

    color: #132c48;

    margin-bottom: 5px;
}


.report-title h2::after {

    content: "";

    display: block;

    width: 50px;

    height: 3px;

    background: #1466ad;

    margin-top: 8px;
}


/* FILTER */

.filters {

    display: flex;

    gap: 12px;

    align-items: center;
}


.filters select {

    height: 43px;

    min-width: 150px;

    border:
        1px solid
        #d2d8df;

    background: white;

    border-radius: 5px;

    padding: 0 13px;

    font-size: 15px;

    color: #394b5f;
}


.generate-btn {

    height: 43px;

    border: none;

    background: #1264ad;

    color: white;

    border-radius: 5px;

    padding: 0 20px;

    font-size: 15px;

    cursor: pointer;

    font-weight: bold;
}


.generate-btn:hover {

    background: #0b518f;
}


/* =========================================================
   STAT CARDS
   ========================================================= */

.stats-grid {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 18px;
}


.stat-card {

    min-height: 145px;

    background: white;

    border:
        1px solid
        #dce4ec;

    border-radius: 6px;

    padding: 24px;

    display: flex;

    align-items: center;

    gap: 18px;
}


.stat-icon {

    width: 54px;

    height: 54px;

    border-radius: 50%;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 27px;

    flex-shrink: 0;
}


.stat-content h3 {

    font-size: 15px;

    line-height: 21px;

    color: #1c2937;

    margin-bottom: 8px;
}


.stat-content .number {

    font-size: 38px;

    font-weight: bold;

    line-height: 40px;
}


/* CARD COLORS */

.card-blue {

    background: #edf6ff;
}


.card-blue .stat-icon {

    background: #2b78c5;

    color: white;
}


.card-blue .number {

    color: #1566b2;
}


.card-green {

    background: #effaf2;
}


.card-green .stat-icon {

    background: #42b45f;

    color: white;
}


.card-green .number {

    color: #239547;
}


.card-yellow {

    background: #fffaf0;
}


.card-yellow .stat-icon {

    background: #f1ac09;

    color: white;
}


.card-yellow .number {

    color: #e99c00;
}


.card-purple {

    background: #f7f2ff;
}


.card-purple .stat-icon {

    background: #7942b6;

    color: white;
}


.card-purple .number {

    color: #69359f;
}


.card-red {

    background: #fff3f3;
}


.card-red .stat-icon {

    background: #e83d3d;

    color: white;
}


.card-red .number {

    color: #db2f2f;
}


.card-cyan {

    background: #eefaff;
}


.card-cyan .stat-icon {

    background: #0c85a7;

    color: white;
}


.card-cyan .number {

    color: #057b9c;
}


/* =========================================================
   SECOND ROW
   ========================================================= */

.second-grid {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 25px;
}


/* AVERAGE CARD */

.average-card {

    grid-column: span 2;

    background: white;

    border:
        1px solid
        #dce4ec;

    border-radius: 6px;

    min-height: 145px;

    display: grid;

    grid-template-columns: 1fr 1fr;

    padding: 20px;
}


.average-box {

    display: flex;

    align-items: center;

    gap: 16px;

    padding-left: 15px;
}


.average-box + .average-box {

    border-left:
        1px solid
        #d7dce1;
}


.average-icon {

    font-size: 43px;

    color: #333;
}


.average-text h3 {

    font-size: 15px;

    margin-bottom: 7px;

    color: #29323d;
}


.average-number {

    font-size: 32px;

    font-weight: bold;

    color: #333;
}


.average-number span {

    font-size: 15px;

    display: block;

    margin-top: 2px;
}


.star {

    color: #543a76;

    font-size: 43px;
}


/* =========================================================
   LOWER GRID
   ========================================================= */

.lower-grid {

    display: grid;

    grid-template-columns:
        1.1fr 0.9fr;

    gap: 22px;

    margin-bottom: 22px;
}


/* PANEL */

.panel {

    background: white;

    border:
        1px solid
        #dce4ec;

    border-radius: 6px;

    overflow: hidden;
}


.panel-title {

    font-size: 17px;

    font-weight: bold;

    padding: 17px 18px;

    border-bottom:
        1px solid
        #dce4ec;

    color: #193653;
}


/* =========================================================
   DEPARTMENT TABLE
   ========================================================= */

.table-wrapper {

    overflow-x: auto;
}


.department-table {

    width: 100%;

    border-collapse: collapse;
}


.department-table th {

    background: #073558;

    color: white;

    padding: 11px 10px;

    font-size: 13px;

    text-align: center;
}


.department-table th:first-child {

    text-align: left;
}


.department-table td {

    padding: 10px;

    border-bottom:
        1px solid
        #e1e5e9;

    font-size: 13px;

    text-align: center;
}


.department-table td:first-child {

    text-align: left;
}


.department-table tr:hover {

    background: #f5f9fc;
}


.department-table .total-row {

    background: #e3f0fb;

    font-weight: bold;

    color: #163c5f;
}


/* =========================================================
   DONUT CHART
   ========================================================= */

.chart-area {

    min-height: 360px;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 30px;

    padding: 25px;
}


.donut {

    width: 260px;

    height: 260px;

    border-radius: 50%;

    background:

        conic-gradient(

            #397dcc
            0 <?php echo $closedPercent; ?>%,

            #45b964
            <?php echo $closedPercent; ?>%
            <?php echo $closedPercent + $resolvedPercent; ?>%,

            #f2ab00
            <?php echo $closedPercent + $resolvedPercent; ?>%
            <?php echo $closedPercent + $resolvedPercent + $pendingPercent; ?>%,

            #7041b5
            <?php echo $closedPercent + $resolvedPercent + $pendingPercent; ?>%
            <?php echo $closedPercent + $resolvedPercent + $pendingPercent + $progressPercent; ?>%,

            #e44b48
            <?php echo $closedPercent + $resolvedPercent + $pendingPercent + $progressPercent; ?>%
            100%
        );

    position: relative;

    flex-shrink: 0;
}


.donut::after {

    content: "";

    position: absolute;

    width: 115px;

    height: 115px;

    background: white;

    border-radius: 50%;

    top: 50%;

    left: 50%;

    transform:
        translate(-50%, -50%);
}


/* LEGEND */

.legend {

    display: flex;

    flex-direction: column;

    gap: 18px;
}


.legend-item {

    display: flex;

    align-items: center;

    gap: 10px;

    font-size: 14px;
}


.legend-dot {

    width: 15px;

    height: 15px;

    border-radius: 50%;

    flex-shrink: 0;
}


.blue {
    background: #397dcc;
}


.green {
    background: #45b964;
}


.orange {
    background: #f2ab00;
}


.purple {
    background: #7041b5;
}


.red {
    background: #e44b48;
}


/* =========================================================
   FOOTER REPORT BAR
   ========================================================= */

.report-footer {

    background: white;

    border:
        1px solid
        #dce4ec;

    border-radius: 6px;

    min-height: 65px;

    padding: 12px 20px;

    display: flex;

    justify-content: space-between;

    align-items: center;
}


.generated-time {

    color: #39444e;

    font-size: 13px;
}


.report-buttons {

    display: flex;

    gap: 15px;
}


.report-btn {

    border: none;

    border-radius: 5px;

    color: white;

    padding: 10px 17px;

    font-size: 14px;

    font-weight: bold;

    cursor: pointer;
}


.excel {

    background: #178b46;
}


.pdf {

    background: #d9342b;
}


.print {

    background: #1766ad;
}


.report-btn:hover {

    opacity: 0.88;
}


/* =========================================================
   MOBILE
   ========================================================= */

@media(max-width: 1200px) {

    .stats-grid {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .second-grid {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .average-card {

        grid-column: span 2;
    }

    .lower-grid {

        grid-template-columns: 1fr;
    }
}


@media(max-width: 800px) {

    .sidebar {

        width: 220px;
    }

    .topbar {

        left: 220px;
    }

    .main {

        margin-left: 220px;
    }

    .report-header {

        flex-direction: column;

        align-items: flex-start;

        gap: 20px;
    }

    .chart-area {

        flex-direction: column;
    }
}


@media(max-width: 600px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .topbar {

        position: relative;

        left: 0;

        height: 60px;
    }

    .main {

        margin-left: 0;

        padding: 20px 12px;
    }

    .stats-grid {

        grid-template-columns: 1fr;
    }

    .second-grid {

        grid-template-columns: 1fr;
    }

    .average-card {

        grid-column: span 1;

        grid-template-columns: 1fr;
    }

    .average-box {

        padding: 15px;
    }

    .average-box + .average-box {

        border-left: none;

        border-top:
            1px solid
            #d7dce1;
    }

    .filters {

        width: 100%;

        flex-wrap: wrap;
    }

    .filters select {

        flex: 1;

        min-width: 120px;
    }

    .report-footer {

        flex-direction: column;

        gap: 15px;

        align-items: flex-start;
    }

    .report-buttons {

        flex-wrap: wrap;
    }
}

</style>

</head>


<body>


<!-- =====================================================
     LEFT SIDEBAR
     ===================================================== -->

<aside class="sidebar">


    <div class="logo-area">

        <div class="logo-icon">
            ✚
        </div>

        <div class="logo-text">

            <h1>AIIMS</h1>

            <p>
                Hospital Complaint<br>
                Management System
            </p>

        </div>

    </div>


    <nav class="navigation">

        <a href="hospital_admin_dashboard.php"
           class="active">

            <span class="nav-icon">◉</span>

            <span>Dashboard</span>

        </a>


        <a href="register_complaint.php">

            <span class="nav-icon">✎</span>

            <span>Register Complaint</span>

        </a>


        <a href="track_complaint.php">

            <span class="nav-icon">⌕</span>

            <span>Track Complaint</span>

        </a>


        <a href="complaints.php">

            <span class="nav-icon">☷</span>

            <span>Complaints</span>

        </a>


        <a href="departments.php">

            <span class="nav-icon">▦</span>

            <span>Departments</span>

        </a>


        <a href="reports.php">

            <span class="nav-icon">▥</span>

            <span>Reports</span>

        </a>


        <a href="feedback.php">

            <span class="nav-icon">★</span>

            <span>Feedback</span>

        </a>


        <a href="admin_logout.php">

            <span class="nav-icon">↪</span>

            <span>Logout</span>

        </a>

    </nav>

</aside>



<!-- =====================================================
     TOP BAR
     ===================================================== -->

<header class="topbar">

    <div class="admin-profile">

        <div class="admin-circle">
            ●
        </div>

        <span>
            <?php
            echo htmlspecialchars(
                $_SESSION["admin"]
            );
            ?>
        </span>

        <span>⌄</span>

    </div>

</header>



<!-- =====================================================
     MAIN CONTENT
     ===================================================== -->

<main class="main">


    <!-- REPORT HEADER -->

    <div class="report-header">


        <div class="report-title">

            <div class="report-icon">
                ▣
            </div>

            <div>

                <h2>
                    Monthly Complaint Report
                </h2>

            </div>

        </div>


        <form
            method="GET"
            class="filters"
        >

            <select name="month">

                <?php foreach ($months as $number => $monthName): ?>

                    <option
                        value="<?php echo $number; ?>"
                        <?php
                        if ($selectedMonth == $number) {
                            echo "selected";
                        }
                        ?>
                    >
                        <?php echo $monthName; ?>
                    </option>

                <?php endforeach; ?>

            </select>


            <select name="year">

                <?php

                $currentYear =
                    intval(date("Y"));

                for (
                    $year = $currentYear - 5;
                    $year <= $currentYear + 2;
                    $year++
                ):

                ?>

                    <option
                        value="<?php echo $year; ?>"
                        <?php
                        if ($selectedYear == $year) {
                            echo "selected";
                        }
                        ?>
                    >
                        <?php echo $year; ?>
                    </option>

                <?php endfor; ?>

            </select>


            <button
                type="submit"
                class="generate-btn"
            >
                ⚑ Generate Report
            </button>

        </form>

    </div>



    <!-- =================================================
         FIRST ROW CARDS
         ================================================= -->

    <section class="stats-grid">


        <!-- TOTAL -->

        <div class="stat-card card-blue">

            <div class="stat-icon">
                ▤
            </div>

            <div class="stat-content">

                <h3>
                    Total Complaints<br>
                    Received
                </h3>

                <div class="number">
                    <?php
                    echo $totalComplaints;
                    ?>
                </div>

            </div>

        </div>



        <!-- RESOLVED -->

        <div class="stat-card card-green">

            <div class="stat-icon">
                ✓
            </div>

            <div class="stat-content">

                <h3>
                    Resolved Complaints
                </h3>

                <div class="number">
                    <?php
                    echo $resolvedComplaints;
                    ?>
                </div>

            </div>

        </div>



        <!-- PENDING -->

        <div class="stat-card card-yellow">

            <div class="stat-icon">
                ◷
            </div>

            <div class="stat-content">

                <h3>
                    Pending Complaints
                </h3>

                <div class="number">
                    <?php
                    echo $pendingComplaints;
                    ?>
                </div>

            </div>

        </div>



        <!-- PROGRESS -->

        <div class="stat-card card-purple">

            <div class="stat-icon">
                ⚙
            </div>

            <div class="stat-content">

                <h3>
                    In Progress<br>
                    Complaints
                </h3>

                <div class="number">
                    <?php
                    echo $progressComplaints;
                    ?>
                </div>

            </div>

        </div>

    </section>



    <!-- =================================================
         SECOND ROW
         ================================================= -->

    <section class="second-grid">


        <!-- DELAYED -->

        <div class="stat-card card-red">

            <div class="stat-icon">
                !
            </div>

            <div class="stat-content">

                <h3>
                    Delayed Complaints
                </h3>

                <div class="number">
                    <?php
                    echo $delayedComplaints;
                    ?>
                </div>

            </div>

        </div>



        <!-- CLOSED -->

        <div class="stat-card card-cyan">

            <div class="stat-icon">
                🔒
            </div>

            <div class="stat-content">

                <h3>
                    Closed Complaints
                </h3>

                <div class="number">
                    <?php
                    echo $closedComplaints;
                    ?>
                </div>

            </div>

        </div>



        <!-- AVERAGE -->

        <div class="average-card">


            <div class="average-box">

                <div class="average-icon">
                    ◷
                </div>

                <div class="average-text">

                    <h3>
                        Average Resolution Time
                    </h3>

                    <div class="average-number">

                        <?php
                        echo $averageResolution;
                        ?>

                        <span>
                            Days
                        </span>

                    </div>

                </div>

            </div>



            <div class="average-box">

                <div class="star">
                    ★
                </div>

                <div class="average-text">

                    <h3>
                        Average Satisfaction Rating
                    </h3>

                    <div class="average-number">

                        <?php
                        echo $averageSatisfaction;
                        ?>
                        / 5

                        <span>
                            (Good)
                        </span>

                    </div>

                </div>

            </div>

        </div>

    </section>



    <!-- =================================================
         LOWER SECTION
         ================================================= -->

    <section class="lower-grid">


        <!-- DEPARTMENT SUMMARY -->

        <div class="panel">

            <div class="panel-title">

                Department-wise Summary

            </div>


            <div class="table-wrapper">

                <table class="department-table">

                    <thead>

                    <tr>

                        <th>
                            Department
                        </th>

                        <th>
                            Total Complaints
                        </th>

                        <th>
                            Resolved
                        </th>

                        <th>
                            Pending
                        </th>

                        <th>
                            In Progress
                        </th>

                        <th>
                            Delayed
                        </th>

                    </tr>

                    </thead>


                    <tbody>

                    <?php

                    $grandTotal = 0;
                    $grandResolved = 0;
                    $grandPending = 0;
                    $grandProgress = 0;
                    $grandDelayed = 0;


                    if (count($departmentData) > 0):

                        foreach (
                            $departmentData
                            as $department =>
                            $data
                        ):

                            $grandTotal +=
                                $data["total"];

                            $grandResolved +=
                                $data["resolved"];

                            $grandPending +=
                                $data["pending"];

                            $grandProgress +=
                                $data["progress"];

                            $grandDelayed +=
                                $data["delayed"];

                    ?>

                    <tr>

                        <td>
                            <?php
                            echo htmlspecialchars(
                                $department
                            );
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $data["total"];
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $data["resolved"];
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $data["pending"];
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $data["progress"];
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $data["delayed"];
                            ?>
                        </td>

                    </tr>

                    <?php

                        endforeach;

                    else:

                    ?>

                    <tr>

                        <td colspan="6"
                            style="text-align:center;
                                   padding:25px;">

                            No department complaint
                            data available.

                        </td>

                    </tr>

                    <?php endif; ?>


                    <tr class="total-row">

                        <td>
                            Total
                        </td>

                        <td>
                            <?php
                            echo $grandTotal;
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $grandResolved;
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $grandPending;
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $grandProgress;
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $grandDelayed;
                            ?>
                        </td>

                    </tr>

                    </tbody>

                </table>

            </div>

        </div>



        <!-- =================================================
             STATUS DISTRIBUTION
             ================================================= -->

        <div class="panel">

            <div class="panel-title">

                Complaint Status Distribution

            </div>


            <div class="chart-area">


                <div
                    class="donut"
                    title="Complaint Status Distribution"
                >
                </div>


                <div class="legend">


                    <div class="legend-item">

                        <span
                            class="legend-dot blue"
                        ></span>

                        <span>
                            Closed Complaints
                            (<?php
                            echo $closedComplaints;
                            ?>)
                        </span>

                    </div>


                    <div class="legend-item">

                        <span
                            class="legend-dot green"
                        ></span>

                        <span>
                            Resolved Complaints
                            (<?php
                            echo $resolvedComplaints;
                            ?>)
                        </span>

                    </div>


                    <div class="legend-item">

                        <span
                            class="legend-dot orange"
                        ></span>

                        <span>
                            Pending Complaints
                            (<?php
                            echo $pendingComplaints;
                            ?>)
                        </span>

                    </div>


                    <div class="legend-item">

                        <span
                            class="legend-dot purple"
                        ></span>

                        <span>
                            In Progress Complaints
                            (<?php
                            echo $progressComplaints;
                            ?>)
                        </span>

                    </div>


                    <div class="legend-item">

                        <span
                            class="legend-dot red"
                        ></span>

                        <span>
                            Delayed Complaints
                            (<?php
                            echo $delayedComplaints;
                            ?>)
                        </span>

                    </div>


                </div>

            </div>

        </div>

    </section>



    <!-- =================================================
         REPORT FOOTER
         ================================================= -->

    <div class="report-footer">


        <div class="generated-time">

            Report Generated On:

            <?php
            echo date(
                "d M Y h:i A"
            );
            ?>

        </div>


        <div class="report-buttons">


            <button
                class="report-btn excel"
                onclick="exportExcel()"
            >

                ▣ Export Excel

            </button>


            <button
                class="report-btn pdf"
                onclick="exportPDF()"
            >

                ▣ Export PDF

            </button>


            <button
                class="report-btn print"
                onclick="window.print()"
            >

                ▣ Print Report

            </button>


        </div>

    </div>


</main>



<script>

/* =========================================================
   EXPORT EXCEL
   ========================================================= */

function exportExcel() {

    alert(
        "Excel export can be connected to your PHP export file."
    );

}


/* =========================================================
   EXPORT PDF
   ========================================================= */

function exportPDF() {

    alert(
        "PDF export can be connected to your PHP PDF file."
    );

}

</script>


</body>

</html>