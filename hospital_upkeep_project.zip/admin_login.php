<?php

session_start();

require_once "db.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "" || $password === "") {

        $error = "Please enter username and password.";

    } else {

        $stmt = $pdo->prepare(
            "SELECT * FROM admins WHERE username = ? LIMIT 1"
        );

        $stmt->execute([$username]);

        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($password, $admin["password"])) {

            $_SESSION["admin_logged_in"] = true;
            $_SESSION["admin_id"] = $admin["id"];
            $_SESSION["admin_name"] = $admin["name"];

            header("Location: admin_dashboard.php");
            exit;

        } else {

            $error = "Invalid admin username or password.";

        }

    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>AIIMS Raipur - Admin Login</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    background: #eef5f9;
    min-height: 100vh;

    display: flex;
    align-items: center;
    justify-content: center;
}

.login-box {

    width: 420px;
    max-width: 92%;

    background: white;

    padding: 35px;

    border-radius: 12px;

    box-shadow:
        0 8px 30px rgba(0,0,0,.12);

}

.logo {

    text-align: center;

    margin-bottom: 20px;

}

.logo img {

    width: 85px;
    height: 85px;
    object-fit: contain;

}

h1 {

    text-align: center;

    color: #005b96;

    margin-bottom: 8px;

}

.subtitle {

    text-align: center;

    color: #777;

    margin-bottom: 25px;

}

.error {

    background: #f8d7da;

    color: #842029;

    padding: 12px;

    border-radius: 6px;

    margin-bottom: 18px;

}

.form-group {

    margin-bottom: 18px;

}

label {

    display: block;

    font-weight: bold;

    margin-bottom: 7px;

}

input {

    width: 100%;

    padding: 13px;

    border: 1px solid #bbb;

    border-radius: 6px;

    font-size: 15px;

}

button {

    width: 100%;

    padding: 13px;

    background: #005b96;

    border: none;

    border-radius: 6px;

    color: white;

    font-size: 16px;

    font-weight: bold;

    cursor: pointer;

}

button:hover {

    background: #003f6b;

}

.back {

    text-align: center;

    margin-top: 20px;

}

.back a {

    color: #005b96;

    text-decoration: none;

}

</style>

</head>

<body>

<div class="login-box">

    <div class="logo">

        <img src="images/aiims_logo.png"
             alt="AIIMS Logo">

    </div>

    <h1>Admin Login</h1>

    <div class="subtitle">
        Hospital Upkeep Complaint Management System
    </div>

    <?php if ($error): ?>

        <div class="error">
            <?= htmlspecialchars($error) ?>
        </div>

    <?php endif; ?>

    <form method="POST">

        <div class="form-group">

            <label>Admin Username</label>

            <input
                type="text"
                name="username"
                placeholder="Enter admin username"
                required
            >

        </div>

        <div class="form-group">

            <label>Password</label>

            <input
                type="password"
                name="password"
                placeholder="Enter password"
                required
            >

        </div>

        <button type="submit">
            Login to Admin Dashboard
        </button>

    </form>

    <div class="back">

        <a href="index.php">
            ← Back to Website
        </a>

    </div>

</div>

</body>

</html>