<?php
session_start();
include_once "db.php";

if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}

if (!isset($_GET["id"])) {
    die("Complaint ID is missing.");
}

$complaint_id = intval($_GET["id"]);

$sql = "SELECT * FROM complaints WHERE complaint_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $complaint_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Complaint not found.");
}

$complaint = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $department = $_POST["department"];
    $officer_name = $_POST["officer_name"];
    $officer_designation = $_POST["officer_designation"];
    $officer_contact = $_POST["officer_contact"];

    $sql = "UPDATE complaints
            SET department = ?,
                officer_name = ?,
                officer_designation = ?,
                officer_contact = ?,
                complaint_status = 'Assigned'
            WHERE complaint_id = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssssi",
        $department,
        $officer_name,
        $officer_designation,
        $officer_contact,
        $complaint_id
    );

    if ($stmt->execute()) {
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $error = "Unable to assign complaint.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Assign Complaint</title>

<style>

body {
    font-family: Arial, sans-serif;
    background: #f4f6f9;
    margin: 0;
    padding: 30px;
}

.container {
    max-width: 700px;
    margin: auto;
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

h2 {
    color: #333;
    margin-bottom: 25px;
}

.complaint-box {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
}

label {
    display: block;
    margin-top: 15px;
    margin-bottom: 6px;
    font-weight: bold;
}

input,
select {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 6px;
    box-sizing: border-box;
}

button {
    margin-top: 25px;
    width: 100%;
    padding: 13px;
    border: none;
    border-radius: 6px;
    background: #6f42c1;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #59339d;
}

.error {
    color: red;
}

</style>

</head>

<body>

<div class="container">

<h2>4. Assign to Concerned Department / Officer</h2>

<div class="complaint-box">

<strong>Complaint ID:</strong>
<?php echo $complaint["complaint_id"]; ?>

<br><br>

<strong>Complaint:</strong>
<?php echo htmlspecialchars($complaint["complaint"]); ?>

</div>

<?php if (isset($error)) { ?>

<p class="error">
<?php echo $error; ?>
</p>

<?php } ?>

<form method="POST">

<label>Department</label>

<select name="department" required>

<option value="">Select Department</option>

<option value="Administration">Administration</option>

<option value="Medical Department">Medical Department</option>

<option value="Nursing Department">Nursing Department</option>

<option value="Pharmacy">Pharmacy</option>

<option value="Engineering">Engineering</option>

<option value="Housekeeping">Housekeeping</option>

<option value="Security">Security</option>

<option value="IT Department">IT Department</option>

</select>

<label>Officer Name</label>

<input
    type="text"
    name="officer_name"
    placeholder="Enter officer name"
    required
>

<label>Designation</label>

<input
    type="text"
    name="officer_designation"
    placeholder="Enter designation"
    required
>

<label>Contact Number</label>

<input
    type="text"
    name="officer_contact"
    placeholder="Enter contact number"
    maxlength="15"
    required
>

<button type="submit">
    Assign Complaint
</button>

</form>

</div>

</body>
</html>