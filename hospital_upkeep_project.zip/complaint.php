<?php

include_once "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Complaint Raised By
    $name_designation = $_POST["name_designation"] ?? "";
    $mobile = $_POST["mobile"] ?? "";
    $email = $_POST["email"] ?? "";

    // Department / Ward / Area
    $ward_area = $_POST["ward_area"] ?? "";
    $location = $_POST["location"] ?? "";

    // Complaint Details
    $category = $_POST["category"] ?? "";
    $complaint_title = $_POST["complaint_title"] ?? "";
    $description = $_POST["description"] ?? "";

    // Generate unique Complaint ID
    $complaint_id = "CMP" . time();

    // Image upload
    $image_path = NULL;

    if (
        isset($_FILES["complaint_image"]) &&
        $_FILES["complaint_image"]["error"] == 0
    ) {

        $upload_dir = "uploads/";

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $extension = strtolower(
            pathinfo(
                $_FILES["complaint_image"]["name"],
                PATHINFO_EXTENSION
            )
        );

        $allowed_types = ["jpg", "jpeg", "png", "gif"];

        if (!in_array($extension, $allowed_types)) {
            die("Only JPG, JPEG, PNG and GIF images are allowed.");
        }

        $check = getimagesize(
            $_FILES["complaint_image"]["tmp_name"]
        );

        if ($check === false) {
            die("Please upload a valid image.");
        }

        $image_name = time() . "_" .
            preg_replace(
                "/[^A-Za-z0-9._-]/",
                "_",
                basename($_FILES["complaint_image"]["name"])
            );

        $image_path = $upload_dir . $image_name;

        if (!move_uploaded_file(
            $_FILES["complaint_image"]["tmp_name"],
            $image_path
        )) {
            die("Failed to upload image.");
        }
    }

    // Insert complaint
    $sql = "INSERT INTO complaints
        (
            complaint_id,
            name_designation,
            contact_number,
            email,
            ward_area,
            location,
            service_category,
            complaint_title,
            complaint_description,
            complaint_image
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }

$stmt->bind_param(
    "ssssssssss",
    $complaint_id,
    $name_designation,
    $mobile,
    $email,
    $ward_area,
    $location,
    $category,
    $complaint_title,
    $description,
    $image_path
);

    if ($stmt->execute()) {

        echo "<div style='
                max-width:700px;
                margin:50px auto;
                padding:30px;
                background:#ffffff;
                border-radius:10px;
                text-align:center;
                font-family:Arial;
                box-shadow:0 2px 10px rgba(0,0,0,0.1);
              '>";

        echo "<h2 style='color:green;'>
                Complaint Submitted Successfully!
              </h2>";

        echo "<p>Your Complaint ID is:
                <b>" . htmlspecialchars($complaint_id) . "</b>
              </p>";

        if ($image_path != NULL) {

            echo "<p style='color:green;'>
                    Complaint image uploaded successfully.
                  </p>";

            echo "<p>
                    <img src='" . htmlspecialchars($image_path) . "'
                         style='max-width:300px;
                                max-height:300px;
                                border-radius:8px;'>
                  </p>";

        } else {

            echo "<p>No image was attached.</p>";
        }

        echo '<br>
              <a href="index.php"
                 style="display:inline-block;
                        padding:10px 20px;
                        background:#007bff;
                        color:white;
                        text-decoration:none;
                        border-radius:5px;">
                 Back to Home
              </a>';

        echo "</div>";

    } else {

        echo "Error submitting complaint: " . $stmt->error;
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html>
<head>

    <title>Submit Complaint</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .section-title {
            background-color: #e9ecef;
            padding: 12px;
            margin-top: 25px;
            margin-bottom: 20px;
            border-left: 5px solid #007bff;
            font-size: 18px;
            font-weight: bold;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 6px;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 18px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
        }

        .submit-btn {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

    </style>

</head>

<body>

<div class="container">

    <h2>Submit a Complaint</h2>

    <!-- ========================= -->
    <!-- COMPLAINT RAISED BY -->
    <!-- ========================= -->

    <div class="section-title">
        Complaint Raised By
    </div>

    <form method="POST" enctype="multipart/form-data">

        <label>Name & Designation:</label>

        <input
            type="text"
            name="name_designation"
            placeholder="Enter your name and designation"
            required
        >


        <label>Contact Number:</label>

        <input
            type="text"
            name="mobile"
            placeholder="Enter contact number"
            required
        >


        <label>Email:</label>

        <input
            type="email"
            name="email"
            placeholder="Enter email address"
            required
        >


        <!-- ========================= -->
        <!-- DEPARTMENT / WARD / AREA -->
        <!-- ========================= -->

        <label>Department / Ward / Area:</label>

        <select name="ward_area" required>

            <option value="">-- Select Department / Ward / Area --</option>

            <option value="1b1 Obgy Ward">1. 1b1 Obgy Ward</option>
            <option value="1b2 Obgy Ward">2. 1b2 Obgy Ward</option>
            <option value="1c1 Paediatrics Ward">3. 1c1 Paediatrics Ward</option>
            <option value="1c2 Paediatrics Ward">4. 1c2 Paediatrics Ward</option>
            <option value="1c3 Nephrology Ward Renal Transplan Ward">5. 1c3 Nephrology Ward Renal Transplan Ward</option>

            <option value="2a1 General Surgery Ward">6. 2a1 General Surgery Ward</option>
            <option value="2a2 General Surgery Ward">7. 2a2 General Surgery Ward</option>
            <option value="2a3 Orthopedic Ward">8. 2a3 Orthopedic Ward</option>
            <option value="2a4 Orthopedic Ward">9. 2a4 Orthopedic Ward</option>
            <option value="2b2 Plastic Surgery Ward">10. 2b2 Plastic Surgery Ward</option>
            <option value="2b4 Surgical Gastroenterology Ward">11. 2b4 Surgical Gastroenterology Ward</option>
            <option value="2c1 Endocrinology Ward">12. 2c1 Endocrinology Ward</option>
            <option value="2c4 Medicine Hdu Ward">13. 2c4 Medicine Hdu Ward</option>
            <option value="2d1 Pulmonary Medicine Ward">14. 2d1 Pulmonary Medicine Ward</option>
            <option value="2d2 Pulmonary Medicine Icu Ward">15. 2d2 Pulmonary Medicine Icu Ward</option>
            <option value="2d3 Medicine Female Ward">16. 2d3 Medicine Female Ward</option>
            <option value="2d4 Medicine Male Ward">17. 2d4 Medicine Male Ward</option>

            <option value="3a1 General Surgery Ward">18. 3a1 General Surgery Ward</option>
            <option value="3a2 Medical Oncology Hematology Ward">19. 3a2 Medical Oncology Hematology Ward</option>
            <option value="3a3 Dental Ward & ENT Ward">20. 3a3 Dental Ward & ENT Ward</option>
            <option value="3a4 Ent Ward">21. 3a4 Ent Ward</option>
            <option value="3b1 Neurology Ward">22. 3b1 Neurology Ward</option>
            <option value="3b2 Neurosurgery Ward">23. 3b2 Neurosurgery Ward</option>
            <option value="3b3 Cardiology Ward">24. 3b3 Cardiology Ward</option>
            <option value="3b4 Ctvs Ward">25. 3b4 Ctvs Ward</option>
            <option value="3c1 Nephrology Ward">26. 3c1 Nephrology Ward</option>
            <option value="3c2 Urology Ward">27. 3c2 Urology Ward</option>
            <option value="3c3 Ophthalmology Ward">28. 3c3 Ophthalmology Ward</option>
            <option value="3c4 Pediatric Surgery Ward">29. 3c4 Pediatric Surgery Ward</option>
            <option value="3d1 Pvt Ward">30. 3d1 Pvt Ward</option>
            <option value="3d2 Private Ward">31. 3d2 Private Ward</option>
            <option value="3d4 Med Oncology Hematology Day Care">32. 3d4 Med Oncology Hematology Day Care</option>

            <option value="4c1 Cardiology ICCU I">33. 4c1 Cardiology ICCU I</option>
            <option value="4c2 Cardiology ICCU II">34. 4c2 Cardiology ICCU II</option>
            <option value="4c3 Neurosurgery ICU Ward">35. 4c3 Neurosurgery ICU Ward</option>
            <option value="4c4 CTVS ICU Ward">36. 4c4 CTVS ICU Ward</option>
            <option value="4d1 Medicine ICU Ward">37. 4d1 Medicine ICU Ward</option>

            <option value="A Block Major OT">38. A Block Major OT</option>
            <option value="Ayush 2nd Floor Gen Ward">39. Ayush 2nd Floor Gen Ward</option>
            <option value="Ayush Covid">40. Ayush Covid</option>
            <option value="Ayush Isolation">41. Ayush Isolation</option>
            <option value="B Block OT Area">42. B Block OT Area</option>

            <option value="Trauma & Emergency Ground Floor">43. Trauma & Emergency Ground Floor</option>
            <option value="Trauma ICU 1st Floor">44. Trauma ICU 1st Floor</option>
            <option value="CCU Trauma 2nd Floor">45. CCU Trauma 2nd Floor</option>
            <option value="Trauma and Emergency OT 3rd Floor">46. Trauma and Emergency OT 3rd Floor</option>
            <option value="Pediatric Emergency ward">47. Pediatric Emergency ward</option>
            <option value="A Block Minor OT">48. A Block Minor OT</option>
            <option value="Covid ICU Ward">49. Covid ICU Ward</option>
            <option value="Emergency Medicine">50. Emergency Medicine</option>
            <option value="Hemodialysis Unit C-Block Basement">51. Hemodialysis Unit C-Block Basement</option>
            <option value="NICU">52. NICU</option>
            <option value="Hemodialysis Unit Trauma-Block 1st Floor">53. Hemodialysis Unit Trauma-Block 1st Floor</option>
            <option value="Nuclear Medicine Ward">54. Nuclear Medicine Ward</option>
            <option value="Obg Labour Room Ward">55. Obg Labour Room Ward</option>
            <option value="Obg OT">56. Obg OT</option>
            <option value="Blood Bank">57. Blood Bank</option>

            <option value="Ayurveda OPD">58. Ayurveda OPD</option>
            <option value="Breast Cancer Clinic OPD">59. Breast Cancer Clinic OPD</option>
            <option value="Burns & Plastic Surgery OPD">60. Burns & Plastic Surgery OPD</option>
            <option value="Cardiology OPD">61. Cardiology OPD</option>
            <option value="Cardiothoracic and Vascular Surgery OPD">62. Cardiothoracic and Vascular Surgery OPD</option>
            <option value="CFM Immunization (Tikakaran) OPD">63. CFM Immunization (Tikakaran) OPD</option>
            <option value="Dentistry OPD">64. Dentistry OPD</option>
            <option value="Dermatology OPD">65. Dermatology OPD</option>
            <option value="Endocrinology OPD">66. Endocrinology OPD</option>
            <option value="ENT OPD">67. ENT OPD</option>
            <option value="Gastroenterology and Human Nutrition OPD">68. Gastroenterology and Human Nutrition OPD</option>
            <option value="Gastrointestinal Surgery OPD">69. Gastrointestinal Surgery OPD</option>
            <option value="Hematology OPD">70. Hematology OPD</option>
            <option value="Homeopathy OPD">71. Homeopathy OPD</option>
            <option value="Medical Oncology OPD">72. Medical Oncology OPD</option>
            <option value="Medicine OPD">73. Medicine OPD</option>
            <option value="Nephrology OPD">74. Nephrology OPD</option>
            <option value="Neurology OPD">75. Neurology OPD</option>
            <option value="Neurosurgery OPD">76. Neurosurgery OPD</option>
            <option value="Nuclear Medicine Therapy Clinic OPD">77. Nuclear Medicine Therapy Clinic OPD</option>
            <option value="Obstetrics and Gynaecology OPD">78. Obstetrics and Gynaecology OPD</option>
            <option value="Ophthalmology OPD">79. Ophthalmology OPD</option>
            <option value="Orthopaedics OPD">80. Orthopaedics OPD</option>
            <option value="PAC OPD">81. PAC OPD</option>
            <option value="Paediatrics OPD">82. Paediatrics OPD</option>
            <option value="Paediatric Surgery OPD">83. Paediatric Surgery OPD</option>
            <option value="Pain Clinic OPD">84. Pain Clinic OPD</option>
            <option value="Plastic Surgery OPD">85. Plastic Surgery OPD</option>
            <option value="PMR OPD">86. PMR OPD</option>
            <option value="Psychiatry OPD">87. Psychiatry OPD</option>
            <option value="Pulmonary Medicine OPD">88. Pulmonary Medicine OPD</option>
            <option value="Radiotherapy OPD">89. Radiotherapy OPD</option>
            <option value="Radiodiagnosis Department">90. Radiodiagnosis Department</option>
            <option value="Screening OPD">91. Screening OPD</option>
            <option value="Siddha OPD">92. Siddha OPD</option>
            <option value="Surgery OPD">93. Surgery OPD</option>
            <option value="Surgical Oncology OPD">94. Surgical Oncology OPD</option>
            <option value="Unani OPD">95. Unani OPD</option>
            <option value="Urology OPD">96. Urology OPD</option>
            <option value="Yoga OPD">97. Yoga OPD</option>

            <option value="Central Pharmacy">98. Central Pharmacy</option>
            <option value="Medical Records Department">99. Medical Records Department</option>
            <option value="Canteen D-Block">100. Canteen D-Block</option>
            <option value="Canteen Trauma Block">101. Canteen Trauma Block</option>
            <option value="Dome 1">102. Dome 1</option>
            <option value="Dome 2">103. Dome 2</option>
            <option value="Dome 3">104. Dome 3</option>

            <!-- LAST OPTION -->
            <option value="Other">105. Other</option>

        </select>


        <label>Department Location: Block & Floor:</label>

        <input
            type="text"
            name="location"
            placeholder="Example: Block A - 2nd Floor"
            required
        >


        <!-- ========================= -->
        <!-- COMPLAINT DETAILS -->
        <!-- ========================= -->

        <div class="section-title">
            Complaint Details
        </div>


        <label>Service Category:</label>

        <select name="category" required>

            <option value="">-- Select Service Category --</option>

            <option value="Civil">
                Civil
            </option>

            <option value="Electrical">
                Electrical
            </option>

            <option value="Plumbing">
                Plumbing
            </option>

            <option value="Other">
                Other
            </option>

        </select>


        <label>Complaint Title:</label>

        <input
            type="text"
            name="complaint_title"
            placeholder="Enter complaint title"
            required
        >


        <label>Complaint Description:</label>

        <textarea
            name="description"
            rows="6"
            placeholder="Describe your complaint in detail"
            required
        ></textarea>


        <!-- ========================= -->
        <!-- IMAGE ATTACHMENT -->
        <!-- ========================= -->

        <div class="section-title">
            Complaint Image Attachment
        </div>

        <label>Attach Complaint Image:</label>

        <input
            type="file"
            name="complaint_image"
            accept=".jpg,.jpeg,.png,.gif"
        >


        <!-- ========================= -->
        <!-- SUBMIT -->
        <!-- ========================= -->

        <button
            type="submit"
            class="submit-btn"
        >
            Submit Complaint
        </button>

    </form>

</div>

</body>
</html>