<?php

$host = "YOUR_INFINITYFREE_HOST";
$username = "YOUR_INFINITYFREE_USERNAME";
$password = "YOUR_INFINITYFREE_PASSWORD";
$database = "YOUR_INFINITYFREE_DATABASE";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");