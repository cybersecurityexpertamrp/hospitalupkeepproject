<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

error_reporting(E_ALL);
ini_set('display_errors', 1);

/*
========================================================
AIIMS RAIPUR - HOSPITAL UPKEEP COMPLAINT MANAGEMENT SYSTEM
SINGLE PAGE APPLICATION
========================================================
*/


/* =====================================================
   BASIC CONFIGURATION
===================================================== */

$admin_notification_email = "admin@aiimsraipur.edu.in";

/* =====================================================
   SMS GATEWAY CONFIGURATION
   Fill these in with your SMS gateway provider details
   (e.g. MSG91, Twilio, Fast2SMS, etc.) to enable SMS
   notifications to the assigned worker's contact number
   whenever the admin assigns / updates work.
   Leave $sms_enabled = false to disable SMS sending
   without touching the rest of the code.
===================================================== */

$sms_enabled   = false;                          // set true once the gateway details below are filled in
$sms_api_url   = "https://your-sms-gateway.example.com/api/send";
$sms_api_key   = "YOUR_SMS_GATEWAY_API_KEY";
$sms_sender_id = "AIIMSR";                        // sender ID / from name registered with your gateway


/* =====================================================
   DATA STORAGE HELPERS (FILE BASED - USERS, FEEDBACK &
   COMPLAINTS)
   Registered users, feedback and complaints must survive
   logout / new sessions and must be visible to both the
   user and every admin, so they all live in JSON files
   instead of $_SESSION.
===================================================== */

$users_file      = __DIR__ . '/data/users.json';
$feedback_file   = __DIR__ . '/data/feedback.json';
$complaints_file = __DIR__ . '/data/complaints.json';
$admins_file     = __DIR__ . '/data/admins.json';

function loadJsonData($file) {

    if (!file_exists($file)) {
        return [];
    }

    $raw = @file_get_contents($file);
    $decoded = json_decode($raw, true);

    return is_array($decoded) ? $decoded : [];
}

function saveJsonData($file, $data) {

    $dir = dirname($file);

    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }

    @file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT)
    );
}


/* =====================================================
   SEED DEFAULT DEPARTMENT ADMIN ACCOUNTS (FILE BASED)
   The four department admin accounts (Civil, Electrical,
   AC and RO, Pest Control) now live in a JSON file instead
   of being hardcoded, so the Main Admin can create, edit
   and delete them from the Manage Admins screen. This only
   runs once - the first time the system is used - to seed
   the original default accounts so nothing breaks.
===================================================== */

function seedDefaultAdmins($admins_file) {

    if (file_exists($admins_file)) {
        return;
    }

    $default_admins = [

        [
            'id'         => uniqid('adm_'),
            'department' => 'Civil & Plumbing',
            'username'   => 'civil',
            'password'   => password_hash('civil123', PASSWORD_DEFAULT),
            'created_on' => date("d-m-Y h:i A")
        ],

        [
            'id'         => uniqid('adm_'),
            'department' => 'AC and RO',
            'username'   => 'AC and RO',
            'password'   => password_hash('acro123', PASSWORD_DEFAULT),
            'created_on' => date("d-m-Y h:i A")
        ],

        [
            'id'         => uniqid('adm_'),
            'department' => 'Electrical',
            'username'   => 'electrical',
            'password'   => password_hash('electrical123', PASSWORD_DEFAULT),
            'created_on' => date("d-m-Y h:i A")
        ],

        [
            'id'         => uniqid('adm_'),
            'department' => 'Pest Control',
            'username'   => 'Pest Control',
            'password'   => password_hash('Pestcontrol123', PASSWORD_DEFAULT),
            'created_on' => date("d-m-Y h:i A")
        ]

    ];

    saveJsonData($admins_file, $default_admins);
}

seedDefaultAdmins($admins_file);


/* =====================================================
   LOAD PERSISTED COMPLAINTS (FILE BASED)
   Complaints must stay on record permanently and must be
   visible on both the user dashboard and the admin
   dashboard, so they are loaded from file into
   $_SESSION['complaints'] on every request. All existing
   code below keeps reading/writing $_SESSION['complaints']
   exactly as before; it is saved back to file right after
   a complaint is submitted or updated.
===================================================== */

$_SESSION['complaints'] = loadJsonData($complaints_file);


/* =====================================================
   LOGOUT
===================================================== */

if (isset($_GET['logout'])) {

    session_destroy();

    header("Location: index.php?page=login");

    exit();
}


/* =====================================================
   DEFAULT PAGE
===================================================== */

$page = isset($_GET['page'])
    ? $_GET['page']
    : 'home';


/* =====================================================
   DEFAULT USER DASHBOARD VIEW
===================================================== */

$user_view = isset($_GET['view'])
    ? $_GET['view']
    : 'dashboard';


/* =====================================================
   DEFAULT ADMIN DASHBOARD VIEW
===================================================== */

$admin_view = isset($_GET['view'])
    ? $_GET['view']
    : 'dashboard';


/* =====================================================
   USER LOGIN (checks real registered accounts)
===================================================== */

$user_login_error = "";

if (isset($_POST['user_login'])) {

    $username = trim($_POST['user_username'] ?? '');
    $password = trim($_POST['user_password'] ?? '');
   $captcha_answer_submitted =
    trim($_POST['captcha_answer'] ?? '');

if (
    !isset($_SESSION['captcha_answer']) ||
    strcasecmp(
        $captcha_answer_submitted,
        $_SESSION['captcha_answer']
    ) !== 0
) {
    $login_error = "Invalid captcha.";
} else {

        $registered_users = loadJsonData($users_file);

        $matched_user = null;

        foreach ($registered_users as $registered) {

            if (
                isset($registered['username']) &&
                strcasecmp($registered['username'], $username) === 0
            ) {
                $matched_user = $registered;
                break;
            }
        }

        if (
            $matched_user !== null &&
            isset($matched_user['password']) &&
            password_verify($password, $matched_user['password'])
        ) {

            $_SESSION['user_logged_in'] = true;
            $_SESSION['username'] = $matched_user['username'];
            $_SESSION['user_name_designation'] = $matched_user['name_designation'] ?? $matched_user['username'];
            $_SESSION['user_email'] = $matched_user['email'] ?? '';
            $_SESSION['user_mobile'] = $matched_user['mobile'] ?? '';

            unset($_SESSION['captcha_answer']);

            header("Location: index.php?page=user_dashboard");

            exit();

        } else {

            $user_login_error =
                "Invalid username or password. If you don't have an account yet, please contact the hospital administrator to get your account registered.";

            generateCaptcha();
        }
    }
}


/* =====================================================
   ADMIN LOGIN
===================================================== */

$admin_login_error = "";
$admin_login_type = "";


/*
========================================================
MAIN ADMIN CREDENTIALS
The Main Admin is the super administrator of the system.
The Main Admin does not handle a single maintenance
department - instead the Main Admin creates, edits and
removes the department admin accounts (Civil, Electrical,
AC and RO, Pest Control) and can also register new user
accounts. Change this password after first login.
========================================================
*/

$main_admin_username = "mainadmin";
$main_admin_password = "MainAdmin@123";


if (isset($_POST['admin_login'])) {

    $username =
        trim($_POST['admin_username'] ?? '');

    $password =
        trim($_POST['admin_password'] ?? '');

    $admin_login_type =
        trim($_POST['admin_type'] ?? '');


    if ($admin_login_type === "Main Admin") {

        if (
            $username === $main_admin_username &&
            $password === $main_admin_password
        ) {

            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
            $_SESSION['admin_type'] = "Main Admin";
            $_SESSION['is_main_admin'] = true;

            header("Location: index.php?page=admin_dashboard");

            exit();

        } else {

            $admin_login_error =
                "Invalid Main Admin username or password.";
        }

    } else {

        $registered_admins = loadJsonData($admins_file);

        $matched_admin = null;

        foreach ($registered_admins as $registered) {

            if (
                isset($registered['department']) &&
                strcasecmp($registered['department'], $admin_login_type) === 0 &&
                isset($registered['username']) &&
                strcasecmp($registered['username'], $username) === 0
            ) {
                $matched_admin = $registered;
                break;
            }
        }

        if (
            $matched_admin !== null &&
            isset($matched_admin['password']) &&
            password_verify($password, $matched_admin['password'])
        ) {

            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $matched_admin['username'];
            $_SESSION['admin_type'] = $matched_admin['department'];
            $_SESSION['is_main_admin'] = false;

            header("Location: index.php?page=admin_dashboard");

            exit();

        } else {

            $admin_login_error =
                "Invalid " .
                $admin_login_type .
                " admin username or password.";
        }
    }
}


/* =====================================================
   REGISTER (creates a real account you can log in with)
   Only an admin (Main Admin or a department admin) can
   register a new user account now - there is no direct
   public self-registration. Anyone opening the register
   page without an admin session is redirected to the
   admin login screen first.
===================================================== */

$register_message = "";
$register_success = false;

if (
    isset($_POST['register_user']) &&
    isset($_SESSION['admin_logged_in'])
) {

    $reg_username =
        trim($_POST['username'] ?? '');

    $name_designation =
        trim($_POST['name_designation'] ?? '');

    $department =
        trim($_POST['department'] ?? '');

    $email =
        trim($_POST['email'] ?? '');

    $mobile =
        trim($_POST['mobile'] ?? '');

    $joining_date =
        trim($_POST['joining_date'] ?? '');

    $password =
        trim($_POST['password'] ?? '');

    $confirm_password =
        trim($_POST['confirm_password'] ?? '');


    if (
        $reg_username != "" &&
        $name_designation != "" &&
        $department != "" &&
        $email != "" &&
        $mobile != "" &&
        $joining_date != "" &&
        $password != "" &&
        $confirm_password != ""
    ) {

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

            $register_message =
                "Please enter a valid email address.";

        } elseif (strlen($password) < 6) {

            $register_message =
                "Password must be at least 6 characters long.";

        } elseif ($password !== $confirm_password) {

            $register_message =
                "Password and Confirm Password do not match.";

        } else {

            $registered_users = loadJsonData($users_file);

            $username_taken = false;
            $email_taken = false;

            foreach ($registered_users as $registered) {

                if (
                    isset($registered['username']) &&
                    strcasecmp($registered['username'], $reg_username) === 0
                ) {
                    $username_taken = true;
                }

                if (
                    isset($registered['email']) &&
                    strcasecmp($registered['email'], $email) === 0
                ) {
                    $email_taken = true;
                }
            }

            if ($username_taken) {

                $register_message =
                    "This username is already taken. Please choose another username.";

            } elseif ($email_taken) {

                $register_message =
                    "This email is already registered. Please login instead.";

            } else {

                $registered_users[] = [

                    'username' => $reg_username,
                    'name_designation' => $name_designation,
                    'department' => $department,
                    'email' => $email,
                    'mobile' => $mobile,
                    'joining_date' => $joining_date,
                    'password' => password_hash($password, PASSWORD_DEFAULT),
                    'registered_by' => $_SESSION['admin_username'] ?? '',
                    'registered_on' => date("d-m-Y h:i A")
                ];

                saveJsonData($users_file, $registered_users);

                $register_message =
                    "Registration successful. The user can now login using this username and password.";

                $register_success = true;
            }
        }

    } else {

        $register_message =
            "Please fill all registration details.";
    }
}


/* =====================================================
   MAIN ADMIN - ADD DEPARTMENT ADMIN
===================================================== */

$admin_manage_message = "";

if (
    isset($_POST['add_admin']) &&
    isset($_SESSION['admin_logged_in']) &&
    !empty($_SESSION['is_main_admin'])
) {

    $new_department =
        trim($_POST['new_admin_department'] ?? '');

    $new_username =
        trim($_POST['new_admin_username'] ?? '');

    $new_password =
        trim($_POST['new_admin_password'] ?? '');

    $new_confirm_password =
        trim($_POST['new_admin_confirm_password'] ?? '');


    if (
        $new_department === "" ||
        $new_username === "" ||
        $new_password === "" ||
        $new_confirm_password === ""
    ) {

        $admin_manage_message =
            "Please fill all admin details.";

    } elseif (strlen($new_password) < 6) {

        $admin_manage_message =
            "Password must be at least 6 characters long.";

    } elseif ($new_password !== $new_confirm_password) {

        $admin_manage_message =
            "Password and Confirm Password do not match.";

    } else {

        $existing_admins = loadJsonData($admins_file);

        $username_taken = false;

        foreach ($existing_admins as $existing) {

            if (
                isset($existing['department'], $existing['username']) &&
                strcasecmp($existing['department'], $new_department) === 0 &&
                strcasecmp($existing['username'], $new_username) === 0
            ) {
                $username_taken = true;
            }
        }

        if ($username_taken) {

            $admin_manage_message =
                "An admin with this username already exists in this department.";

        } else {

            $existing_admins[] = [
                'id'         => uniqid('adm_'),
                'department' => $new_department,
                'username'   => $new_username,
                'password'   => password_hash($new_password, PASSWORD_DEFAULT),
                'created_on' => date("d-m-Y h:i A")
            ];

            saveJsonData($admins_file, $existing_admins);

            $admin_manage_message =
                "New " . $new_department . " admin added successfully.";
        }
    }
}


/* =====================================================
   MAIN ADMIN - UPDATE DEPARTMENT ADMIN
===================================================== */

if (
    isset($_POST['update_admin']) &&
    isset($_SESSION['admin_logged_in']) &&
    !empty($_SESSION['is_main_admin'])
) {

    $admin_id =
        trim($_POST['admin_id'] ?? '');

    $upd_department =
        trim($_POST['edit_admin_department'] ?? '');

    $upd_username =
        trim($_POST['edit_admin_username'] ?? '');

    $upd_password =
        trim($_POST['edit_admin_password'] ?? '');


    $existing_admins = loadJsonData($admins_file);

    $found_admin_index = -1;

    foreach ($existing_admins as $i => $existing) {

        if (($existing['id'] ?? '') === $admin_id) {

            $found_admin_index = $i;

            break;
        }
    }

    if ($found_admin_index === -1) {

        $admin_manage_message =
            "Admin record not found.";

    } elseif ($upd_department === "" || $upd_username === "") {

        $admin_manage_message =
            "Please fill department and username.";

    } else {

        $existing_admins[$found_admin_index]['department'] = $upd_department;
        $existing_admins[$found_admin_index]['username'] = $upd_username;

        if ($upd_password !== "") {

            if (strlen($upd_password) < 6) {

                $admin_manage_message =
                    "Password must be at least 6 characters long.";

            } else {

                $existing_admins[$found_admin_index]['password'] =
                    password_hash($upd_password, PASSWORD_DEFAULT);
            }
        }

        if ($admin_manage_message === "") {

            saveJsonData($admins_file, $existing_admins);

            $admin_manage_message =
                "Admin details updated successfully.";
        }
    }
}


/* =====================================================
   MAIN ADMIN - DELETE DEPARTMENT ADMIN
===================================================== */

if (
    isset($_POST['delete_admin']) &&
    isset($_SESSION['admin_logged_in']) &&
    !empty($_SESSION['is_main_admin'])
) {

    $admin_id =
        trim($_POST['admin_id'] ?? '');

    $existing_admins = loadJsonData($admins_file);

    $found_admin_index = -1;

    foreach ($existing_admins as $i => $existing) {

        if (($existing['id'] ?? '') === $admin_id) {

            $found_admin_index = $i;

            break;
        }
    }

    if ($found_admin_index === -1) {

        $admin_manage_message =
            "Admin record not found.";

    } else {

        array_splice($existing_admins, $found_admin_index, 1);

        saveJsonData($admins_file, $existing_admins);

        $admin_manage_message =
            "Admin removed successfully.";
    }
}


/* =====================================================
   MAIN ADMIN - DELETE REGISTERED USER
   Lets the Main Admin remove an existing registered user
   record from the permanent (file based) user list, shown
   alongside the "Existing User ID Records" table on the
   Register User screen.
===================================================== */

$user_manage_message = "";

if (
    isset($_POST['delete_user']) &&
    isset($_SESSION['admin_logged_in']) &&
    !empty($_SESSION['is_main_admin'])
) {

    $delete_username = trim($_POST['username'] ?? '');

    $registered_users = loadJsonData($users_file);

    $remaining_users = array_values(
        array_filter(
            $registered_users,
            function ($u) use ($delete_username) {
                return strcasecmp($u['username'] ?? '', $delete_username) !== 0;
            }
        )
    );

    if (count($remaining_users) === count($registered_users)) {

        $user_manage_message =
            "User record not found.";

    } else {

        saveJsonData($users_file, $remaining_users);

        $user_manage_message =
            "User account removed successfully.";
    }
}


/* =====================================================
   WARD / AREA LIST
===================================================== */

$ward_area_list = [

    "1b1 Obgy Ward",
    "1b2 Obgy Ward",
    "1c1 Paediatrics Ward",
    "1c2 Paediatrics Ward",
    "1c3 Nephrology Ward Renal Transplan Ward",

    "2a1 General Surgery Ward",
    "2a2 General Surgery Ward",
    "2a3 Orthopedic Ward",
    "2a4 Orthopedic Ward",
    "2b2 Plastic Surgery Ward",
    "2b4 Surgical Gastroenterology Ward",
    "2c1 Endocrinology Ward",
    "2c4 Medicine Hdu Ward",
    "2d1 Pulmonary Medicine Ward",
    "2d2 Pulmonary Medicine Icu Ward",
    "2d3 Medicine Female Ward",
    "2d4 Medicine Male Ward",

    "3a1 General Surgery Ward",
    "3a2 Medical Oncology Hematology Ward",
    "3a3 Dental Ward & ENT Ward",
    "3a4 Ent Ward",
    "3b1 Neurology Ward",
    "3b2 Neurosurgery Ward",
    "3b3 Cardiology Ward",
    "3b4 Ctvs Ward",
    "3c1 Nephrology Ward",
    "3c2 Urology Ward",
    "3c3 Ophthalmology Ward",
    "3c4 Pediatric Surgery Ward",
    "3d1 Pvt Ward",
    "3d2 Private Ward",
    "3d4 Med Oncology Hematology Day Care",

    "4c1 Cardiology ICCU I",
    "4c2 Cardiology ICCU II",
    "4c3 Neurosurgery ICU Ward",
    "4c4 CTVS ICU Ward",
    "4d1 Medicine ICU Ward",

    "A Block Major OT",
    "Ayush 2nd Floor Gen Ward",
    "Ayush Covid",
    "Ayush Isolation",
    "B Block OT Area",

    "Trauma & Emergency Ground Floor",
    "Trauma ICU 1st Floor",
    "CCU Trauma 2nd Floor",
    "Trauma and Emergency OT 3rd Floor",
    "Pediatric Emergency ward",

    "A Block Minor OT",
    "Covid ICU Ward",
    "Emergency Medicine",
    "Hemodialysis Unit C-Block Basement",
    "NICU",
    "Hemodialysis Unit Trauma-Block 1st Floor",
    "Nuclear Medicine Ward",
    "Obg Labour Room Ward",
    "Obg OT",
    "Blood Bank",

    "Ayurveda OPD",
    "Breast Cancer Clinic OPD",
    "Burns & Plastic Surgery OPD",
    "Cardiology OPD",
    "Cardiothoracic and Vascular Surgery OPD",
    "CFM Immunization (Tikakaran) OPD",
    "Dentistry OPD",
    "Dermatology OPD",
    "Endocrinology OPD",
    "ENT OPD",
    "Gastroenterology and Human Nutrition OPD",
    "Gastrointestinal Surgery OPD",
    "Hematology OPD",
    "Homeopathy OPD",
    "Medical Oncology OPD",
    "Medicine OPD",
    "Nephrology OPD",
    "Neurology OPD",
    "Neurosurgery OPD",
    "Nuclear Medicine Therapy Clinic OPD",
    "Obstetrics and Gynaecology OPD",
    "Ophthalmology OPD",
    "Orthopaediatrics OPD",
    "PAC OPD",
    "Paediatrics OPD",
    "Paediatric Surgery OPD",
    "Pain Clinic OPD",
    "Plastic Surgery OPD",
    "PMR OPD",
    "Psychiatry OPD",
    "Pulmonary Medicine OPD",
    "Radiotherapy OPD",
    "Radiodiagnosis Department",
    "Screening OPD",
    "Siddha OPD",
    "Surgery OPD",
    "Surgical Oncology OPD",
    "Unani OPD",
    "Urology OPD",
    "Yoga OPD",

    "Central Pharmacy",
    "Medical Records Department",
    "Canteen D-Block",
    "Canteen Trauma Block",
    "Dome 1",
    "Dome 2",
    "Dome 3"
];


/* =====================================================
   HELPER - SEND EMAIL
===================================================== */

function sendNotificationEmail(
    $to,
    $subject,
    $message
) {

    $headers =
        "From: AIIMS Raipur Complaint System\r\n" .
        "Reply-To: admin@aiimsraipur.edu.in\r\n" .
        "Content-Type: text/plain; charset=UTF-8\r\n";

    @mail(
        $to,
        $subject,
        $message,
        $headers
    );
}


/* =====================================================
   HELPER - SEND SMS
   Sends a plain text SMS to the given mobile number using
   the SMS gateway configured at the top of this file.
   Silently does nothing if SMS is disabled or the number
   is missing/invalid, so the rest of the system keeps
   working even without a gateway configured.
===================================================== */

function sendSmsNotification(
    $mobile,
    $message
) {

    global $sms_enabled, $sms_api_url, $sms_api_key, $sms_sender_id;

    $mobile = preg_replace('/[^0-9]/', '', (string) $mobile);

    if (
        !$sms_enabled ||
        $mobile === "" ||
        strlen($mobile) < 10
    ) {
        return false;
    }

    $payload = [
        'api_key'   => $sms_api_key,
        'sender_id' => $sms_sender_id,
        'mobile'    => $mobile,
        'message'   => $message
    ];

    $ch = @curl_init($sms_api_url);

    if ($ch === false) {
        return false;
    }

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    @curl_exec($ch);
    $success = curl_errno($ch) === 0;

    curl_close($ch);

    return $success;
}


/* =====================================================
   HELPER - GENERATE USER LOGIN CAPTCHA
   Creates a fresh, simple math captcha (two random numbers
   to add together) and stores it in the session so the
   User Login form can display it and the login handler can
   verify the answer. Called for every fresh view of the
   User Login page and again after any failed login attempt
   so the same captcha can never be reused.
===================================================== */

function generateCaptcha() {

    $characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $captcha = '';

    for ($i = 0; $i < 6; $i++) {
        $captcha .= $characters[random_int(0, strlen($characters) - 1)];
    }

    $_SESSION['captcha_answer'] = $captcha;
}


/* =====================================================
   HELPER - RENDER HOME / LOGIN PAGE TABS
   Renders the 3 login tabs (User Login, Departmental
   Login, Admin Login) used on both the Home page and the
   Login page so the markup only needs to be maintained in
   one place. Pure front-end tab switching (no page reload)
   is handled by the shared <script> block at the bottom of
   the page.
===================================================== */

function renderLoginTabs() {

?>

<div class="login-tabs">

    <div class="login-tab-buttons">

        <button type="button" class="login-tab-btn active" data-target="tab-user-login">
        User Login
        </button>

        <button type="button" class="login-tab-btn" data-target="tab-departmental-login">
        Departmental Login
        </button>

        <button type="button" class="login-tab-btn" data-target="tab-admin-login">
        Admin Login
        </button>

    </div>


    <div class="login-tab-panel" id="tab-user-login" style="display:block;">

        <div class="login-options" style="grid-template-columns:1fr;max-width:420px;margin:auto;">

            <div class="login-option">

                <h3>
                User Login
                </h3>

                <p>
                Login as a registered hospital user to raise
                and track complaints.
                </p>

                <a href="index.php?page=user_login" class="btn">
                USER LOGIN
                </a>

            </div>

        </div>

    </div>


    <div class="login-tab-panel" id="tab-departmental-login" style="display:none;">

        <div class="login-options" style="grid-template-columns:1fr;max-width:420px;margin:auto;">

            <div class="login-option">

                <h3>
                Departmental Login
                </h3>

                <p>
                Login as a Civil &amp; Plumbing, Electrical,
                AC &amp; RO or Pest Control department
                administrator.
                </p>

                <a href="index.php?page=departmental_login" class="btn">
                DEPARTMENTAL LOGIN
                </a>

            </div>

        </div>

    </div>


    <div class="login-tab-panel" id="tab-admin-login" style="display:none;">

        <div class="login-options" style="grid-template-columns:1fr;max-width:420px;margin:auto;">

            <div class="login-option">

                <h3>
                Admin Login
                </h3>

                <p>
                Login as Main Admin to manage department
                admins and registered users.
                </p>

                <a href="index.php?page=admin_login" class="btn">
                ADMIN LOGIN
                </a>

            </div>

        </div>

    </div>

</div>

<?php

}


/* =====================================================
   USER COMPLAINT
===================================================== */

$complaint_message = "";

if (
    isset($_POST['submit_complaint']) &&
    isset($_SESSION['user_logged_in'])
) {

    $name_designation =
        trim($_POST['name_designation'] ?? '');

    $contact_number =
        trim($_POST['contact_number'] ?? '');

    $complaint_email =
        trim($_POST['complaint_email'] ?? '');

    $department_ward_area =
        trim($_POST['department_ward_area'] ?? '');

    $department_location =
        trim($_POST['department_location'] ?? '');

    $type =
        trim($_POST['complaint_type'] ?? '');

    $complaint_title =
        trim($_POST['complaint_title'] ?? '');

    $description =
        trim($_POST['description'] ?? '');


    if (
        $name_designation != "" &&
        $contact_number != "" &&
        $complaint_email != "" &&
        $department_ward_area != "" &&
        $department_location != "" &&
        $type != "" &&
        $complaint_title != "" &&
        $description != ""
    ) {

        if (!isset($_SESSION['complaints'])) {

            $_SESSION['complaints'] = [];
        }


        /* =================================================
           COMPLAINT ID
        ================================================= */

        $complaint_id =
            "CMP" .
            date("YmdHis") .
            rand(10, 99);


        /* =================================================
           IMAGE UPLOAD
        ================================================= */

        $uploaded_images = [];

        $upload_dir =
            "uploads/complaints/";


        if (!is_dir($upload_dir)) {

            @mkdir(
                $upload_dir,
                0777,
                true
            );
        }


        $allowed_types = [
            'jpg',
            'jpeg',
            'png',
            'gif',
            'webp'
        ];


        if (
            isset($_FILES['complaint_images']) &&
            isset($_FILES['complaint_images']['name']) &&
            is_array(
                $_FILES['complaint_images']['name']
            )
        ) {

            $image_count =
                count(
                    $_FILES['complaint_images']['name']
                );


            for (
                $i = 0;
                $i < $image_count;
                $i++
            ) {

                if (
                    $_FILES['complaint_images']['error'][$i]
                    !== UPLOAD_ERR_OK
                ) {

                    continue;
                }


                $original_name =
                    $_FILES['complaint_images']['name'][$i];


                $tmp_name =
                    $_FILES['complaint_images']['tmp_name'][$i];


                $extension =
                    strtolower(
                        pathinfo(
                            $original_name,
                            PATHINFO_EXTENSION
                        )
                    );


                if (
                    !in_array(
                        $extension,
                        $allowed_types
                    )
                ) {

                    continue;
                }


                $new_name =
                    $complaint_id .
                    "_" .
                    uniqid() .
                    "." .
                    $extension;


                $destination =
                    $upload_dir .
                    $new_name;


                if (
                    move_uploaded_file(
                        $tmp_name,
                        $destination
                    )
                ) {

                    $uploaded_images[] =
                        $destination;
                }
            }
        }


        /* =================================================
           SAVE COMPLAINT
        ================================================= */

        $_SESSION['complaints'][] = [

            'id' =>
                $complaint_id,

            'username' =>
                $_SESSION['username'] ?? 'user',

            'name_designation' =>
                $name_designation,

            'contact_number' =>
                $contact_number,

            'email' =>
                $complaint_email,

            'department_ward_area' =>
                $department_ward_area,

            'department_location' =>
                $department_location,

            'type' =>
                $type,

            'complaint_title' =>
                $complaint_title,

            'description' =>
                $description,

            'images' =>
                $uploaded_images,

            'status' =>
                'Pending',

            'assigned_to' =>
                '',

            'assigned_contact' =>
                '',

            'work_process' =>
                '',

            'delay_reason' =>
                '',

            'admin_message' =>
                'Complaint received and is waiting for admin action.',
           
            'admin_message_date' =>
                date("d-m-Y h:i A"),

            'status_history' =>
                [
                    [
                        'status' => 'Pending',
                        'note'   => 'Complaint registered and is waiting for admin action.',
                        'date'   => date("d-m-Y h:i A")
                    ]
                ],

            'date' =>
                date("d-m-Y"),

            'time' =>
                date("h:i A"),

            'timestamp' =>
                time()
        ];


        $new_index =
            count($_SESSION['complaints']) - 1;


        /*
        ====================================================
        SAVE COMPLAINT PERMANENTLY (FILE BASED)
        So the complaint stays on record and is visible on
        both the user dashboard and the admin dashboard.
        ====================================================
        */

        saveJsonData($complaints_file, $_SESSION['complaints']);


        /*
        ====================================================
        ADMIN EMAIL NOTIFICATION
        ====================================================
        */

        $admin_subject =
            "New AIIMS Complaint - " .
            $complaint_id;

        $admin_email_message =
            "New complaint has been submitted.\n\n" .

            "Complaint ID: " .
            $complaint_id . "\n" .

            "Name & Designation: " .
            $name_designation . "\n" .

            "Contact: " .
            $contact_number . "\n" .

            "Email: " .
            $complaint_email . "\n" .

            "Department/Ward/Area: " .
            $department_ward_area . "\n" .

            "Location: " .
            $department_location . "\n" .

            "Service Category: " .
            $type . "\n" .

            "Complaint Title: " .
            $complaint_title . "\n\n" .

            "Description:\n" .
            $description . "\n\n" .

            "Login to the AIIMS complaint system to assign and process this complaint.";

        sendNotificationEmail(
            $admin_notification_email,
            $admin_subject,
            $admin_email_message
        );


        /*
        ====================================================
        INTERNAL NOTIFICATION
        ====================================================
        */

        if (!isset($_SESSION['notifications'])) {

            $_SESSION['notifications'] = [];
        }


        $_SESSION['notifications'][] = [

            'type' =>
                'New Complaint',

            'complaint_id' =>
                $complaint_id,

            'message' =>
                "New " .
                $type .
                " complaint submitted by " .
                $name_designation,

            'date' =>
                date("d-m-Y h:i A"),

            'read' =>
                false
        ];


        $complaint_message =
            "Complaint submitted successfully. Complaint ID: "
            . $complaint_id;

    } else {

        $complaint_message =
            "Please fill all complaint details.";
    }
}


/* =====================================================
   USER DELETE COMPLAINT
   Only allowed while the complaint has not yet been
   assigned to a worker. Once an admin assigns work, the
   delete option is no longer available in the user
   dashboard.
===================================================== */

$delete_complaint_message = "";

if (
    isset($_POST['delete_complaint']) &&
    isset($_SESSION['user_logged_in'])
) {

    $delete_index =
        intval($_POST['complaint_index'] ?? -1);

    if (
        isset($_SESSION['complaints'][$delete_index]) &&
        ($_SESSION['complaints'][$delete_index]['username'] ?? '')
        === $_SESSION['username']
    ) {

        $target_complaint =
            $_SESSION['complaints'][$delete_index];

        if (empty($target_complaint['assigned_to'])) {

            if (!empty($target_complaint['images'])) {

                foreach ($target_complaint['images'] as $old_image) {

                    if (file_exists($old_image)) {

                        @unlink($old_image);
                    }
                }
            }

            array_splice(
                $_SESSION['complaints'],
                $delete_index,
                1
            );

            saveJsonData(
                $complaints_file,
                $_SESSION['complaints']
            );

            $delete_complaint_message =
                "Complaint deleted successfully.";

        } else {

            $delete_complaint_message =
                "This complaint has already been assigned to a worker and can no longer be deleted.";
        }

    } else {

        $delete_complaint_message =
            "Complaint not found.";
    }
}


/* =====================================================
   ADMIN UPDATE COMPLAINT
===================================================== */

$admin_update_message = "";

if (
    isset($_POST['update_complaint']) &&
    isset($_SESSION['admin_logged_in'])
) {

    $complaint_index =
        intval(
            $_POST['complaint_index'] ?? -1
        );

    $new_status =
        trim($_POST['status'] ?? '');

    $assigned_to =
        trim($_POST['assigned_to'] ?? '');

    $assigned_contact =
        trim($_POST['assigned_contact'] ?? '');

    $work_process =
        trim($_POST['work_process'] ?? '');

    $delay_reason =
        trim($_POST['delay_reason'] ?? '');

    $admin_message =
        trim($_POST['admin_message'] ?? '');


    $allowed_statuses = [

        'Pending',
        'Working',
        'Delayed',
        'Resolved',
        'Closed'

    ];


    if (
        isset(
            $_SESSION['complaints']
            [$complaint_index]
        ) &&
        in_array(
            $new_status,
            $allowed_statuses
        )
    ) {

        /*
        ====================================================
        DELAY VALIDATION
        ====================================================
        */

        if (
            $new_status === "Delayed" &&
            $delay_reason === ""
        ) {

            $admin_update_message =
                "Please enter the reason for delay.";

        } else {

            $previous_assigned_to =
                $_SESSION['complaints'][$complaint_index]['assigned_to'] ?? '';

            $previous_assigned_contact =
                $_SESSION['complaints'][$complaint_index]['assigned_contact'] ?? '';


            $_SESSION['complaints']
            [$complaint_index]
            ['status'] =
                $new_status;


            $_SESSION['complaints']
            [$complaint_index]
            ['assigned_to'] =
                $assigned_to;


            $_SESSION['complaints']
            [$complaint_index]
            ['assigned_contact'] =
                $assigned_contact;


            $_SESSION['complaints']
            [$complaint_index]
            ['work_process'] =
                $work_process;


            $_SESSION['complaints']
            [$complaint_index]
            ['delay_reason'] =
                $delay_reason;


            /*
            =================================================
               ADMIN MESSAGE
            =================================================
            */

            if ($admin_message === "") {

                if ($new_status === "Delayed") {

                    $admin_message =
                        "Work is delayed. Reason: " .
                        $delay_reason;

                } elseif ($assigned_to !== "") {

                    $admin_message =
                        "Work assigned to " .
                        $assigned_to .
                        " (" .
                        $assigned_contact .
                        "). Current status: " .
                        $new_status;

                } else {

                    $admin_message =
                        "Complaint status updated to " .
                        $new_status;
                }
            }


            $_SESSION['complaints']
            [$complaint_index]
            ['admin_message'] =
                $admin_message;


            $_SESSION['complaints']
            [$complaint_index]
            ['admin_message_date'] =
                date("d-m-Y h:i A");


            /*
            =================================================
               STATUS HISTORY (for the detailed status
               report - keeps every status change on record
               with its own note and timestamp)
            =================================================
            */

            if (
                !isset($_SESSION['complaints'][$complaint_index]['status_history']) ||
                !is_array($_SESSION['complaints'][$complaint_index]['status_history'])
            ) {
                $_SESSION['complaints'][$complaint_index]['status_history'] = [];
            }

            $_SESSION['complaints'][$complaint_index]['status_history'][] = [
                'status' => $new_status,
                'note'   => $admin_message,
                'date'   => date("d-m-Y h:i A")
            ];


            $user_email =
                $_SESSION['complaints']
                [$complaint_index]['email'] ?? '';


            $complaint_id =
                $_SESSION['complaints']
                [$complaint_index]['id'] ?? '';


            /*
            =================================================
               SEND MESSAGE TO USER EMAIL
            =================================================
            */

            if (
                $user_email !== "" &&
                filter_var(
                    $user_email,
                    FILTER_VALIDATE_EMAIL
                )
            ) {

                $user_subject =
                    "AIIMS Complaint Update - " .
                    $complaint_id;

                $user_email_message =
                    "Your AIIMS Raipur Hospital Upkeep complaint has been updated.\n\n" .

                    "Complaint ID: " .
                    $complaint_id . "\n" .

                    "Status: " .
                    $new_status . "\n" .

                    "Assigned To: " .
                    $assigned_to . "\n" .

                    "Contact: " .
                    $assigned_contact . "\n" .

                    "Work Process: " .
                    $work_process . "\n";

                if (
                    $new_status === "Delayed"
                ) {

                    $user_email_message .=
                        "Delay Reason: " .
                        $delay_reason . "\n";
                }

                $user_email_message .=
                    "\nAdmin Message:\n" .
                    $admin_message . "\n\n" .

                    "Date: " .
                    date("d-m-Y h:i A");


                sendNotificationEmail(
                    $user_email,
                    $user_subject,
                    $user_email_message
                );
            }


            /*
            =================================================
               SEND ASSIGNMENT EMAIL + SMS TO THE ASSIGNED
               WORKER'S CONTACT NUMBER
               Fired whenever a worker/contact is entered
               and it is either new or has changed, so the
               worker is notified about the job assigned to
               them and does not get repeat messages on
               every unrelated status click.
            =================================================
            */

            $is_new_or_changed_assignment =
                $assigned_contact !== "" &&
                (
                    $assigned_contact !== $previous_assigned_contact ||
                    $assigned_to !== $previous_assigned_to
                );

            if ($is_new_or_changed_assignment) {

                $complaint_type_for_sms =
                    $_SESSION['complaints'][$complaint_index]['type'] ?? '';

                $complaint_location_for_sms =
                    $_SESSION['complaints'][$complaint_index]['department_location'] ?? '';

                $worker_sms_message =
                    "AIIMS Raipur: New work assigned - " .
                    $complaint_id . ". " .
                    $complaint_type_for_sms .
                    " complaint at " .
                    $complaint_location_for_sms .
                    ". Status: " . $new_status . ". Details: " . $work_process;

                sendSmsNotification(
                    $assigned_contact,
                    $worker_sms_message
                );
            }


            /*
            =================================================
               USER NOTIFICATION
            =================================================
            */

            if (!isset(
                $_SESSION['user_notifications']
            )) {

                $_SESSION['user_notifications'] = [];
            }


            $_SESSION['user_notifications'][] = [

                'complaint_id' =>
                    $complaint_id,

                'message' =>
                    $admin_message,

                'status' =>
                    $new_status,

                'assigned_to' =>
                    $assigned_to,

                'assigned_contact' =>
                    $assigned_contact,

                'date' =>
                    date("d-m-Y h:i A")
            ];


            /*
            =================================================
               SAVE UPDATED COMPLAINT PERMANENTLY (FILE BASED)
               So the update stays on record and is visible
               on both the user dashboard and the admin
               dashboard.
            =================================================
            */

            saveJsonData($complaints_file, $_SESSION['complaints']);


            $admin_update_message =
                "Complaint updated successfully. User notified by email" .
                ($is_new_or_changed_assignment ? " and the assigned worker was notified by SMS." : ".");
        }
    }
}


/* =====================================================
   USER FEEDBACK SUBMISSION (rating + message, file based
   so the admin can view it as read-only, across sessions)
===================================================== */

$feedback_message = "";

if (
    isset($_POST['submit_feedback']) &&
    isset($_SESSION['user_logged_in'])
) {

    $rating = intval($_POST['rating'] ?? 0);
    $feedback_text = trim($_POST['feedback_text'] ?? '');

    if ($rating < 1 || $rating > 5 || $feedback_text === "") {

        $feedback_message =
            "Please select a rating and enter your feedback message.";

    } else {

        $all_feedback = loadJsonData($feedback_file);

        $all_feedback[] = [

            'username' => $_SESSION['username'],
            'name' => $_SESSION['user_name_designation'] ?? $_SESSION['username'],
            'rating' => $rating,
            'message' => $feedback_text,
            'date' => date("d-m-Y h:i A")
        ];

        saveJsonData($feedback_file, $all_feedback);

        $feedback_message = "Thank you for your feedback.";
    }
}


/* =====================================================
   USER OPERATIONS - CHANGE PASSWORD
   Lets a logged in user change their own password from the
   "Operations" menu on the User Dashboard. Requires the
   correct current password before allowing a new one to be
   set, and updates the permanent (file based) user record.
===================================================== */

$change_password_message = "";

if (
    isset($_POST['change_password_submit']) &&
    isset($_SESSION['user_logged_in'])
) {

    $current_password = trim($_POST['current_password'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_new_password = trim($_POST['confirm_new_password'] ?? '');

    $registered_users = loadJsonData($users_file);

    $found_user_index = -1;

    foreach ($registered_users as $i => $registered) {

        if (
            isset($registered['username']) &&
            strcasecmp($registered['username'], $_SESSION['username']) === 0
        ) {
            $found_user_index = $i;
            break;
        }
    }

    if ($found_user_index === -1) {

        $change_password_message =
            "User account not found.";

    } elseif (
        !isset($registered_users[$found_user_index]['password']) ||
        !password_verify($current_password, $registered_users[$found_user_index]['password'])
    ) {

        $change_password_message =
            "Current password is incorrect.";

    } elseif (strlen($new_password) < 6) {

        $change_password_message =
            "New password must be at least 6 characters long.";

    } elseif ($new_password !== $confirm_new_password) {

        $change_password_message =
            "New Password and Confirm New Password do not match.";

    } else {

        $registered_users[$found_user_index]['password'] =
            password_hash($new_password, PASSWORD_DEFAULT);

        saveJsonData($users_file, $registered_users);

        $change_password_message =
            "Password changed successfully. Please use your new password the next time you login.";
    }
}


/* =====================================================
   DEPARTMENT ADMIN OPERATIONS - CHANGE PASSWORD
   Lets a logged in department admin (Civil & Plumbing,
   Electrical, AC and RO, Pest Control) change their own
   password from the "Operations" menu on the Department
   Dashboard. Requires the correct current password and
   updates the permanent (file based) admin record.
===================================================== */

$admin_change_password_message = "";

if (
    isset($_POST['admin_change_password_submit']) &&
    isset($_SESSION['admin_logged_in']) &&
    empty($_SESSION['is_main_admin'])
) {

    $admin_current_password = trim($_POST['admin_current_password'] ?? '');
    $admin_new_password = trim($_POST['admin_new_password'] ?? '');
    $admin_confirm_new_password = trim($_POST['admin_confirm_new_password'] ?? '');

    $registered_admins_cp = loadJsonData($admins_file);

    $found_admin_cp_index = -1;

    foreach ($registered_admins_cp as $i => $registered) {

        if (
            isset($registered['department'], $registered['username']) &&
            strcasecmp($registered['department'], $_SESSION['admin_type'] ?? '') === 0 &&
            strcasecmp($registered['username'], $_SESSION['admin_username'] ?? '') === 0
        ) {
            $found_admin_cp_index = $i;
            break;
        }
    }

    if ($found_admin_cp_index === -1) {

        $admin_change_password_message =
            "Admin account not found.";

    } elseif (
        !isset($registered_admins_cp[$found_admin_cp_index]['password']) ||
        !password_verify($admin_current_password, $registered_admins_cp[$found_admin_cp_index]['password'])
    ) {

        $admin_change_password_message =
            "Current password is incorrect.";

    } elseif (strlen($admin_new_password) < 6) {

        $admin_change_password_message =
            "New password must be at least 6 characters long.";

    } elseif ($admin_new_password !== $admin_confirm_new_password) {

        $admin_change_password_message =
            "New Password and Confirm New Password do not match.";

    } else {

        $registered_admins_cp[$found_admin_cp_index]['password'] =
            password_hash($admin_new_password, PASSWORD_DEFAULT);

        saveJsonData($admins_file, $registered_admins_cp);

        $admin_change_password_message =
            "Password changed successfully. Please use your new password the next time you login.";
    }
}


/* =====================================================
   ADMIN DELETE FEEDBACK
   Lets an administrator remove old / outdated feedback
   entries from the permanent record.
===================================================== */

$feedback_delete_message = "";

if (
    isset($_POST['delete_feedback']) &&
    isset($_SESSION['admin_logged_in'])
) {

    $feedback_index =
        intval($_POST['feedback_index'] ?? -1);

    $all_feedback_current = loadJsonData($feedback_file);

    if (isset($all_feedback_current[$feedback_index])) {

        array_splice(
            $all_feedback_current,
            $feedback_index,
            1
        );

        saveJsonData($feedback_file, $all_feedback_current);

        $feedback_delete_message =
            "Feedback entry deleted successfully.";

    } else {

        $feedback_delete_message =
            "Feedback entry not found.";
    }
}


/* =====================================================
   HELPER - STATUS COUNT
===================================================== */

function getComplaintCount(
    $status = null,
    $admin_type = null
) {

    $count = 0;


    if (
        isset($_SESSION['complaints']) &&
        is_array($_SESSION['complaints'])
    ) {

        foreach (
            $_SESSION['complaints']
            as $complaint
        ) {

            /*
            ================================================
            ADMIN TYPE FILTER
            ================================================
            */

            if (
                $admin_type !== null &&
                isset($complaint['type']) &&
                strcasecmp(
                    $complaint['type'],
                    $admin_type
                ) !== 0
            ) {

                continue;
            }


            if (
                $status === null ||
                (
                    isset($complaint['status']) &&
                    $complaint['status'] === $status
                )
            ) {

                $count++;
            }
        }
    }


    return $count;
}


/* =====================================================
   GET USER COMPLAINT COUNT
===================================================== */

function getUserComplaintCount(
    $status = null
) {

    $count = 0;


    if (
        isset($_SESSION['complaints']) &&
        is_array($_SESSION['complaints'])
    ) {

        foreach (
            $_SESSION['complaints']
            as $complaint
        ) {

            if (
                !isset($complaint['username']) ||
                $complaint['username']
                !== ($_SESSION['username'] ?? '')
            ) {

                continue;
            }


            if (
                $status === null ||
                (
                    isset($complaint['status']) &&
                    $complaint['status'] === $status
                )
            ) {

                $count++;
            }
        }
    }


    return $count;
}


/* =====================================================
   REPORT PERIOD COUNT
===================================================== */

function getReportCount(
    $period,
    $status = null,
    $admin_type = null,
    $username = null
) {

    $count = 0;

    $today = strtotime(
        date("Y-m-d")
    );


    if (
        !isset($_SESSION['complaints']) ||
        !is_array($_SESSION['complaints'])
    ) {

        return 0;
    }


    foreach (
        $_SESSION['complaints']
        as $complaint
    ) {

        /*
        ================================================
        ADMIN DEPARTMENT FILTER
        ================================================
        */

        if (
            $admin_type !== null &&
            isset($complaint['type']) &&
            strcasecmp(
                $complaint['type'],
                $admin_type
            ) !== 0
        ) {

            continue;
        }


        /*
        ================================================
        USER FILTER
        ================================================
        */

        if (
            $username !== null &&
            (
                !isset($complaint['username']) ||
                $complaint['username'] !== $username
            )
        ) {

            continue;
        }


        if (
            $status !== null &&
            (
                !isset($complaint['status']) ||
                $complaint['status'] !== $status
            )
        ) {

            continue;
        }


        $timestamp =
            isset($complaint['timestamp'])
            ? intval($complaint['timestamp'])
            : 0;


        if ($timestamp <= 0) {

            continue;
        }


        $complaint_day =
            strtotime(
                date(
                    "Y-m-d",
                    $timestamp
                )
            );


        /*
        ================================================
        DAILY
        ================================================
        */

        if ($period === "daily") {

            if (
                $complaint_day ==
                $today
            ) {

                $count++;
            }
        }


        /*
        ================================================
        WEEKLY
        ================================================
        */

        if ($period === "weekly") {

            $week_start =
                strtotime(
                    "monday this week"
                );

            $week_end =
                strtotime(
                    "sunday this week 23:59:59"
                );


            if (
                $timestamp >= $week_start &&
                $timestamp <= $week_end
            ) {

                $count++;
            }
        }


        /*
        ================================================
        MONTHLY
        ================================================
        */

        if ($period === "monthly") {

            if (
                date("Y-m", $timestamp)
                === date("Y-m")
            ) {

                $count++;
            }
        }
    }


    return $count;
}


/* =====================================================
   REPORT PERCENTAGE
===================================================== */

function getPercentage(
    $value,
    $total
) {

    if ($total <= 0) {

        return 0;
    }


    return round(
        ($value / $total) * 100,
        1
    );
}


/* =====================================================
   STATUS CIRCLE
===================================================== */

function statusCircle(
    $label,
    $count,
    $total,
    $class
) {

    $percentage =
        getPercentage(
            $count,
            $total
        );

?>

<div class="circle-report">

    <div
        class="circle <?php echo $class; ?>"
        style="
        --percentage:<?php
        echo $percentage;
        ?>;
        "
    >

        <div class="circle-inner">

            <strong>
                <?php
                echo $percentage;
                ?>%
            </strong>

            <small>
                <?php
                echo $count;
                ?>
            </small>

        </div>

    </div>

    <h4>
        <?php
        echo htmlspecialchars($label);
        ?>
    </h4>

</div>

<?php
}


/* =====================================================
   HELPER - COMPLAINTS FOR A GIVEN PERIOD
   Returns the actual complaint rows (not just the count)
   for the selected reporting period, filtered by admin
   department and/or username exactly like getReportCount,
   so the reports pages can list every complaint under
   each status in detail rather than only a number.
===================================================== */

function getReportComplaints(
    $period,
    $admin_type = null,
    $username = null
) {

    $today = strtotime(date("Y-m-d"));
    $matches = [];

    if (
        !isset($_SESSION['complaints']) ||
        !is_array($_SESSION['complaints'])
    ) {
        return $matches;
    }

    foreach ($_SESSION['complaints'] as $complaint) {

        if (
            $admin_type !== null &&
            isset($complaint['type']) &&
            strcasecmp($complaint['type'], $admin_type) !== 0
        ) {
            continue;
        }

        if (
            $username !== null &&
            (
                !isset($complaint['username']) ||
                $complaint['username'] !== $username
            )
        ) {
            continue;
        }

        $timestamp = isset($complaint['timestamp']) ? intval($complaint['timestamp']) : 0;

        if ($timestamp <= 0) {
            continue;
        }

        $complaint_day = strtotime(date("Y-m-d", $timestamp));
        $in_period = false;

        if ($period === "daily" && $complaint_day == $today) {
            $in_period = true;
        }

        if ($period === "weekly") {
            $week_start = strtotime("monday this week");
            $week_end = strtotime("sunday this week 23:59:59");
            if ($timestamp >= $week_start && $timestamp <= $week_end) {
                $in_period = true;
            }
        }

        if ($period === "monthly" && date("Y-m", $timestamp) === date("Y-m")) {
            $in_period = true;
        }

        if ($in_period) {
            $matches[] = $complaint;
        }
    }

    return $matches;
}


/* =====================================================
   DETAILED STATUS REPORT TABLE
   Renders every complaint for the selected period grouped
   under its current status (Pending, Working, Delayed,
   Resolved, Closed), including the assigned worker, work
   process, delay reason and the full status change history
   so admins/users can see exactly what has happened to
   each complaint, not just a percentage or a count.
===================================================== */

function renderDetailedStatusReport($complaints) {

    $status_order = [
        'Pending'  => 'circle-pending',
        'Working'  => 'circle-working',
        'Delayed'  => 'circle-delayed',
        'Resolved' => 'circle-resolved',
        'Closed'   => 'circle-closed'
    ];

    foreach ($status_order as $status_name => $badge_class) {

        $rows = array_values(array_filter($complaints, function ($c) use ($status_name) {
            return ($c['status'] ?? '') === $status_name;
        }));

        if (count($rows) === 0) {
            continue;
        }

        ?>

        <h3 style="margin-top:25px;">
            <?php echo htmlspecialchars($status_name); ?>
            complaints (<?php echo count($rows); ?>)
        </h3>

        <div class="table-container">

        <table>

        <tr>
            <th>Complaint ID</th>
            <th>Title</th>
            <th>Location</th>
            <th>Assigned To</th>
            <th>Work Process</th>
            <th>Delay Reason</th>
            <th>Latest Update</th>
            <th>Date</th>
        </tr>

        <?php foreach ($rows as $row) { ?>

        <tr>

            <td><?php echo htmlspecialchars($row['id'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($row['complaint_title'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($row['department_location'] ?? ''); ?></td>

            <td>
                <?php echo htmlspecialchars($row['assigned_to'] ?? ''); ?>
                <?php if (!empty($row['assigned_contact'])) { ?>
                    <br><small><?php echo htmlspecialchars($row['assigned_contact']); ?></small>
                <?php } ?>
            </td>

            <td><?php echo htmlspecialchars($row['work_process'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($row['delay_reason'] ?? ''); ?></td>

            <td>
                <?php echo htmlspecialchars($row['admin_message'] ?? ''); ?>
                <br><small><?php echo htmlspecialchars($row['admin_message_date'] ?? ''); ?></small>

                <?php if (!empty($row['status_history']) && is_array($row['status_history'])) { ?>
                    <details style="margin-top:6px;">
                        <summary style="cursor:pointer;color:#075b9d;font-weight:bold;">
                            Full status history
                        </summary>
                        <ul style="margin:8px 0 0 18px;padding:0;">
                            <?php foreach ($row['status_history'] as $entry) { ?>
                                <li style="margin-bottom:6px;">
                                    <span class="status">
                                        <?php echo htmlspecialchars($entry['status'] ?? ''); ?>
                                    </span>
                                    &mdash;
                                    <?php echo htmlspecialchars($entry['note'] ?? ''); ?>
                                    <br><small><?php echo htmlspecialchars($entry['date'] ?? ''); ?></small>
                                </li>
                            <?php } ?>
                        </ul>
                    </details>
                <?php } ?>
            </td>

            <td><?php echo htmlspecialchars($row['date'] ?? ''); ?></td>

        </tr>

        <?php } ?>

        </table>

        </div>

        <?php
    }
}


/* =====================================================
   GENERATE A FRESH USER LOGIN CAPTCHA
   Runs on every plain (GET) view of the User Login page so
   a new captcha is shown each time. A failed login POST
   already generates its own new captcha above, so this is
   skipped in that case to avoid overwriting it.
===================================================== */

if ($page === 'user_login' && !isset($_POST['user_login'])) {

    generateCaptcha();
}


/* =====================================================
   HTML START
===================================================== */

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
AIIMS Raipur - Hospital Upkeep Complaint Management System
</title>


<style>

/* =====================================================
   GENERAL
===================================================== */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background: #f1f7fc;

    color: #16385f;
}


/* =====================================================
   HEADER
===================================================== */

.header {

    background: white;

    min-height: 145px;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 20px 30px;

    border-bottom: 4px solid #075b9d;
}


.header-inner {

    display: flex;

    align-items: center;

    gap: 25px;

    width: 100%;

    max-width: 1250px;
}


.logo {

    width: 105px;

    height: 105px;

    object-fit: contain;

    border-radius: 50%;
}


.title-area {

    text-align: left;
}


.title-area h1 {

    color: #123f70;

    font-size: 29px;

    margin-bottom: 8px;
}


.title-area h2 {

    color: #19558e;

    font-size: 22px;

    margin-bottom: 8px;
}


.title-area h3 {

    color: #075b9d;

    font-size: 20px;

    font-weight: bold;
}


/* =====================================================
   NAVIGATION
===================================================== */

.navbar {

    background: #075b9d;

    min-height: 55px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 5px 25px;

    flex-wrap: wrap;
}


.nav-left,
.nav-right {

    display: flex;

    align-items: center;

    gap: 5px;

    flex-wrap: wrap;
}


.navbar a {

    color: white;

    text-decoration: none;

    padding: 14px 20px;

    font-size: 16px;

    font-weight: bold;

    border-radius: 5px;
}


.navbar a:hover,
.navbar a.active {

    background: white;

    color: #075b9d;
}


/* =====================================================
   HERO
===================================================== */

.hero {

    min-height: 430px;

    position: relative;

    overflow: hidden;

    background: #dceffd;
}


.hero-image {

    position: absolute;

    right: 0;

    top: 0;

    width: 100%;

    height: 100%;

    background-image:

        url("assets/aiims_hospital_img.jpeg");

    background-size: cover;

    background-position: center;
}


.hero-content {

    position: relative;

    z-index: 2;

    width: 50%;

    padding: 75px 0 50px 8%;
}


.welcome {

    color: #ffffff;

    text-shadow: 2px 2px 6px rgba(0,0,0,.85);

    font-size: 25px;

    font-weight: bold;

    margin-bottom: 12px;
}


.hero-content h2 {

    color: #ffffff;

    text-shadow: 2px 2px 6px rgba(0,0,0,.85);

    font-size: 45px;

    line-height: 1.15;

    margin-bottom: 20px;
}


.green-line {

    width: 70px;

    height: 4px;

    background: #219653;

    margin-bottom: 20px;
}


.hero-content p {

    color: #ffffff;

    text-shadow: 2px 2px 6px rgba(0,0,0,.85);

    font-size: 18px;

    line-height: 1.7;

    max-width: 570px;
}


/* =====================================================
   MAIN CONTENT
===================================================== */

.container {

    width: 90%;

    max-width: 1250px;

    margin: 40px auto;
}


.content-box {

    background: white;

    padding: 35px;

    border-radius: 10px;

    box-shadow:
        0 4px 15px rgba(0,0,0,.10);

    margin-bottom: 30px;
}


.content-box h2 {

    color: #075b9d;

    margin-bottom: 20px;

    border-bottom: 3px solid #075b9d;

    padding-bottom: 10px;
}


.content-box h3 {

    color: #1765a8;

    margin: 20px 0 10px;
}


.content-box p {

    color: #444;

    line-height: 1.8;

    margin-bottom: 15px;

    text-align: justify;
}


/* =====================================================
   CARDS
===================================================== */

.cards {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 25px;
}


.card {

    background: white;

    padding: 30px;

    border-radius: 10px;

    text-align: center;

    border-top: 5px solid #075b9d;

    box-shadow:
        0 4px 15px rgba(0,0,0,.10);
}


.card h3 {

    color: #075b9d;

    margin-bottom: 15px;
}


.card p {

    color: #555;

    line-height: 1.6;

    font-size: 30px;

    font-weight: bold;
}


/* =====================================================
   REPORT CARDS
===================================================== */

.report-cards {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 20px;

    margin-top: 20px;
}


.report-card {

    background: #fff;

    padding: 25px;

    border-radius: 10px;

    text-align: center;

    box-shadow:
        0 3px 12px rgba(0,0,0,.10);

    border-left: 5px solid #075b9d;
}


.report-card h3 {

    color: #075b9d;

    margin-bottom: 12px;
}


.report-number {

    font-size: 35px;

    font-weight: bold;

    color: #16385f;
}


/* =====================================================
   CIRCULAR REPORT
===================================================== */

.circular-report-box {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 25px;

    margin-top: 25px;
}


.circle-report {

    background: white;

    padding: 25px;

    border-radius: 12px;

    text-align: center;

    box-shadow:
        0 4px 15px rgba(0,0,0,.10);
}


.circle-report h4 {

    margin-top: 15px;

    font-size: 18px;

    color: #16385f;
}


.circle {

    width: 180px;

    height: 180px;

    border-radius: 50%;

    margin: auto;

    display: flex;

    align-items: center;

    justify-content: center;

    background:
        conic-gradient(
            var(--circle-color)
            calc(var(--percentage) * 1%),
            #e7e7e7
            0
        );
}


.circle-inner {

    width: 125px;

    height: 125px;

    border-radius: 50%;

    background: white;

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;
}


.circle-inner strong {

    font-size: 25px;

    color: #16385f;
}


.circle-inner small {

    font-size: 15px;

    color: #666;

    margin-top: 5px;
}


.circle-pending {

    --circle-color: #f4b400;
}


.circle-working {

    --circle-color: #1976d2;
}


.circle-delayed {

    --circle-color: #e53935;
}


.circle-resolved {

    --circle-color: #198754;
}


.circle-closed {

    --circle-color: #6f42c1;
}


/* =====================================================
   REPORT PERIOD
===================================================== */

.report-period {

    display: flex;

    gap: 10px;

    flex-wrap: wrap;

    margin-bottom: 25px;
}


.report-period a {

    display: inline-block;

    padding: 12px 20px;

    background: #075b9d;

    color: white;

    text-decoration: none;

    border-radius: 5px;

    font-weight: bold;
}


.report-period a:hover {

    background: #043e6d;
}


/* =====================================================
   COMPLAINT TYPES
===================================================== */

.complaint-types {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 25px;
}


.complaint-type {

    padding: 35px;

    text-align: center;

    background: #e9f5ff;

    border: 2px solid #1976bd;

    border-radius: 10px;

    font-size: 22px;

    font-weight: bold;

    color: #075b9d;
}


/* =====================================================
   FORM
===================================================== */

.form-box {

    max-width: 850px;

    margin: auto;

    background: white;

    padding: 35px;

    border-radius: 10px;

    box-shadow:
        0 4px 15px rgba(0,0,0,.10);
}


.form-box label {

    display: block;

    font-weight: bold;

    margin-top: 15px;

    margin-bottom: 7px;
}


.form-box input,
.form-box select,
.form-box textarea {

    width: 100%;

    padding: 12px;

    border: 1px solid #bbb;

    border-radius: 5px;

    font-size: 15px;

    background: white;
}


.form-box textarea {

    height: 120px;

    resize: vertical;
}


.form-box input[type="file"] {

    padding: 10px;

    background: #f8fbff;
}


.btn {

    display: inline-block;

    margin-top: 20px;

    padding: 13px 25px;

    border: none;

    border-radius: 5px;

    background: #075b9d;

    color: white;

    text-decoration: none;

    cursor: pointer;

    font-weight: bold;
}


.btn:hover {

    background: #043e6d;
}


.green-btn {

    background: #198754;
}


.red-btn {

    background: #dc3545;
}


/* =====================================================
   STAR RATING (feedback)
===================================================== */

.rating-group {

    display: flex;

    flex-direction: row-reverse;

    justify-content: flex-end;

    gap: 6px;

    font-size: 34px;

    margin-bottom: 10px;
}


.rating-group input {

    display: none;
}


.rating-group .star-label {

    color: #ccc;

    cursor: pointer;

    margin: 0;

    padding: 0;
    width: auto;
}


.rating-group input:checked ~ .star-label,
.rating-group .star-label:hover,
.rating-group .star-label:hover ~ .star-label {

    color: #f4b400;
}


/* =====================================================
   LOGIN
===================================================== */

.login-options {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 30px;

    max-width: 1000px;

    margin: auto;
}


.login-option {

    background: white;

    padding: 40px;

    text-align: center;

    border-radius: 10px;

    box-shadow:
        0 4px 15px rgba(0,0,0,.12);

    border-top: 5px solid #075b9d;
}


.login-option h3 {

    color: #075b9d;

    margin-bottom: 15px;

    font-size: 25px;
}


/* =====================================================
   LOGIN TABS (User Login / Departmental Login / Admin
   Login shown on the Home page and the Login page)
===================================================== */

.login-tabs {

    max-width: 700px;

    margin: 0 auto;
}


.login-tab-buttons {

    display: flex;

    justify-content: center;

    gap: 10px;

    flex-wrap: wrap;

    margin-bottom: 25px;
}


.login-tab-btn {

    padding: 12px 22px;

    border: 2px solid #075b9d;

    background: white;

    color: #075b9d;

    font-weight: bold;

    font-size: 15px;

    border-radius: 6px;

    cursor: pointer;
}


.login-tab-btn:hover {

    background: #eef7ff;
}


.login-tab-btn.active {

    background: #075b9d;

    color: white;
}


.login-tab-panel {

    animation: none;
}


/* =====================================================
   DASHBOARD LAYOUT
===================================================== */

.dashboard-layout {

    display: grid;

    grid-template-columns: 250px 1fr;

    gap: 25px;

    align-items: start;
}


.dashboard-sidebar {

    background: #075b9d;

    padding: 15px;

    border-radius: 10px;

    position: sticky;

    top: 20px;
}


.dashboard-sidebar h3 {

    color: white;

    padding: 15px;

    border-bottom: 1px solid rgba(255,255,255,.3);

    margin-bottom: 10px;
}


.dashboard-sidebar a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 14px;

    margin-bottom: 6px;

    border-radius: 6px;

    font-weight: bold;
}


.dashboard-sidebar a:hover,
.dashboard-sidebar a.active {

    background: white;

    color: #075b9d;
}


/* =====================================================
   SIDEBAR OPERATIONS MENU (Operations with the
   Change Password sub option)
===================================================== */

.dashboard-sidebar details.sidebar-operations summary {

    display: block;

    color: white;

    padding: 14px;

    margin-bottom: 6px;

    border-radius: 6px;

    font-weight: bold;

    cursor: pointer;

    list-style: none;
}


.dashboard-sidebar details.sidebar-operations summary::-webkit-details-marker {

    display: none;
}


.dashboard-sidebar details.sidebar-operations summary::after {

    content: " \25BE";
}


.dashboard-sidebar details.sidebar-operations[open] summary::after {

    content: " \25B4";
}


.dashboard-sidebar details.sidebar-operations summary:hover {

    background: white;

    color: #075b9d;
}


.dashboard-sidebar details.sidebar-operations a {

    padding-left: 30px;
}


.dashboard-content {

    min-width: 0;
}


.dashboard-title {

    background: #075b9d;

    color: white;

    padding: 20px;

    border-radius: 8px;

    margin-bottom: 20px;
}


.dashboard-title h2 {

    margin-bottom: 8px;
}


/* =====================================================
   TABLE
===================================================== */

.table-container {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;

    background: white;
}


th {

    background: #075b9d;

    color: white;

    padding: 13px;

    text-align: left;
}


td {

    padding: 12px;

    border: 1px solid #ddd;

    vertical-align: top;
}


.status {

    display: inline-block;

    padding: 6px 10px;

    border-radius: 4px;

    font-weight: bold;

    background: #e8f1f8;
}


.status-Pending {

    background: #fff3cd;
    color: #856404;
}


.status-Working {

    background: #cfe2ff;
    color: #084298;
}


.status-Delayed {

    background: #f8d7da;
    color: #842029;
}


.status-Resolved {

    background: #d1e7dd;
    color: #0f5132;
}


.status-Closed {

    background: #e2d9f3;
    color: #432874;
}


/* =====================================================
   PHOTO PREVIEW
===================================================== */

.photo-grid {

    display: flex;

    flex-wrap: wrap;

    gap: 8px;
}


.photo-grid img {

    width: 80px;

    height: 80px;

    object-fit: cover;

    border-radius: 6px;

    border: 1px solid #ccc;
}


/* =====================================================
   MESSAGE
===================================================== */

.message {

    padding: 15px;

    background: #dff5e7;

    border-left: 5px solid #198754;

    margin-bottom: 20px;

    color: #155724;
}


.error {

    background: #ffe0e0;

    border-left-color: #dc3545;

    color: #721c24;
}


/* =====================================================
   NOTIFICATION
===================================================== */

.notification {

    background: #fff8dc;

    border-left: 5px solid #f4b400;

    padding: 15px;

    margin-bottom: 15px;

    border-radius: 5px;
}


.assignment-box {

    background: #f4f9ff;

    border: 1px solid #c9dff2;

    padding: 15px;

    border-radius: 8px;

    min-width: 280px;
}


/* =====================================================
   CONTACT
===================================================== */

.contact-list {

    list-style: none;
}


.contact-list li {

    padding: 14px;

    border-bottom: 1px solid #ddd;

    font-size: 17px;
}


/* =====================================================
   FOOTER
===================================================== */

.footer {

    background: #06366d;

    color: white;

    text-align: center;

    padding: 25px;

    margin-top: 50px;

    line-height: 1.8;
}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:800px) {

    .header-inner {

        flex-direction: column;

        text-align: center;
    }


    .title-area {

        text-align: center;
    }


    .title-area h1 {

        font-size: 22px;
    }


    .title-area h2 {

        font-size: 18px;
    }


    .title-area h3 {

        font-size: 16px;
    }


    .navbar {

        justify-content: center;
    }


    .nav-left,
    .nav-right {

        justify-content: center;

        width: 100%;
    }


    .hero-image {

        width: 100%;

        opacity: .25;
    }


    .hero-content {

        width: 100%;

        padding: 60px 25px;
    }


    .hero-content h2 {

        font-size: 34px;
    }


    .cards,
    .complaint-types,
    .login-options,
    .report-cards,
    .circular-report-box {

        grid-template-columns: 1fr;
    }


    .dashboard-layout {

        grid-template-columns: 1fr;
    }


    .dashboard-sidebar {

        position: static;
    }


    .navbar a {

        padding: 10px 12px;

        font-size: 14px;
    }

}

</style>

</head>


<body>


<!-- =====================================================
     HEADER
===================================================== -->

<header class="header">

<div class="header-inner">

<img
    src="assets/aiims_logo.png"
    alt="AIIMS Hospital Logo"
    class="logo"
>


<div class="title-area">

<h1>
ALL INDIA INSTITUTE OF MEDICAL SCIENCES
</h1>

<h2>
AIIMS RAIPUR - CHHATTISGARH
</h2>

<h3>
HOSPITAL UPKEEP COMPLAINT MANAGEMENT SYSTEM
</h3>

</div>

</div>

</header>


<!-- =====================================================
     NAVIGATION
===================================================== -->

<nav class="navbar">

<div class="nav-left">

<a href="index.php?page=home">
HOME
</a>

<a href="index.php?page=about">
ABOUT
</a>

<a href="index.php?page=contact">
CONTACT
</a>

<a href="index.php?page=complaint">
COMPLAINT
</a>

</div>


<div class="nav-right">

<a href="index.php?page=login">
LOGIN
</a>

</div>

</nav>


<!-- =====================================================
     HERO
===================================================== -->

<?php if ($page == "home") { ?>

<section class="hero">

<div class="hero-image"></div>

<div class="hero-content">

<div class="welcome">
Welcome to AIIMS Raipur
</div>

<h2>
Hospital Upkeep<br>
Complaint Management System
</h2>

<div class="green-line"></div>

<p>
A digital platform designed to support
efficient hospital upkeep, maintenance
reporting and complaint management.
</p>

</div>

</section>

<?php } ?>


<main class="container">


<?php if ($page == "home") { ?>

<div class="content-box">


<div class="content-box">

<h2>
Login Portal
</h2>

<p>
Choose the appropriate login option below to continue.
</p>

<?php renderLoginTabs(); ?>

</div>

<?php } ?>


<!-- =====================================================
     ABOUT
===================================================== -->

<?php if ($page == "about") { ?>

<div class="content-box">

<h2>
About AIIMS Raipur
</h2>

<p>
All India Institute of Medical Sciences, Raipur is a
premier medical institution located in Raipur, Chhattisgarh.
AIIMS institutions are established to provide high-quality
healthcare services while also supporting medical education,
training and research.
</p>

<p>
A hospital environment requires continuous maintenance.
Buildings, electrical systems, plumbing facilities and
other infrastructure need regular monitoring and timely
attention.
</p>

<p>
The Hospital Upkeep Complaint Management System provides
a digital method for recording and managing upkeep-related
complaints. The system focuses on Civil and Plumbing,
Electrical, AC and RO, and Pest Control complaints.
</p>

</div>

<?php } ?>


<!-- =====================================================
     CONTACT
===================================================== -->

<?php if ($page == "contact") { ?>

<div class="content-box">

<h2>
AIIMS Raipur Contact Information
</h2>

<ul class="contact-list">

<li>
<strong>Hospital Name:</strong>
All India Institute of Medical Sciences, Raipur
</li>

<li>
<strong>Location:</strong>
Tatibandh, G.E. Road, Raipur, Chhattisgarh
</li>

<li>
<strong>PIN Code:</strong>
492099
</li>

<li>
<strong>Hospital Enquiry:</strong>
0771-2572240
</li>

<li>
<strong>Emergency Service:</strong>
0771-2577293
</li>

<li>
<strong>Email:</strong>
admin@aiimsraipur.edu.in
</li>

</ul>

</div>

<?php } ?>


<!-- =====================================================
     COMPLAINT INFORMATION
===================================================== -->

<?php if ($page == "complaint") { ?>

<div class="content-box">

<h2>
Hospital Upkeep Complaint Types
</h2>

<p>
The Hospital Upkeep Complaint Management System currently
covers the following maintenance categories:
</p>

<div class="complaint-types" style="grid-template-columns:repeat(4,1fr);">

<div class="complaint-type">
CIVIL &amp; PLUMBING
</div>

<div class="complaint-type">
ELECTRICAL
</div>

<div class="complaint-type">
AC AND RO
</div>

<div class="complaint-type">
PEST CONTROL
</div>

</div>

</div>

<?php } ?>


<!-- =====================================================
     LOGIN OPTIONS
===================================================== -->

<?php if ($page == "login") { ?>

<div class="content-box">

<h2>
Login
</h2>

<?php renderLoginTabs(); ?>

</div>

<?php } ?>


<!-- =====================================================
     USER LOGIN
===================================================== -->

<?php if ($page == "user_login") { ?>

<div class="content-box">

<h2>
User Login
</h2>

<?php if ($user_login_error != "") { ?>

<div class="message error">

<?php
echo htmlspecialchars(
    $user_login_error
);
?>

</div>

<?php } ?>


<div class="form-box">

<form method="POST">

<label>
Username
</label>

<input
type="text"
name="user_username"
required
>


<label>
Password
</label>

<input
type="password"
name="user_password"
required
>


<label>
Captcha:

<strong style="
    font-size:20px;
    letter-spacing:4px;
">
<?php
echo htmlspecialchars(
    $_SESSION['captcha_answer'] ?? ''
);
?>
</strong>
</label>

<input
type="text"
name="captcha_answer"
autocomplete="off"
required
>


<button
type="submit"
name="user_login"
class="btn"
>
LOGIN
</button>

<br>

<a
href="index.php?page=forgot_password"
class="btn"
>
FORGOT PASSWORD
</a>

<p style="margin-top:20px;text-align:center;color:#666;">
New user? Please contact your department administrator -
only an administrator can register a new user account.
</p>

</form>

</div>

</div>

<?php } ?>


<!-- =====================================================
     ADMIN LOGIN (Main Admin - single step login form)
===================================================== -->

<?php if ($page == "admin_login") { ?>

<div class="content-box">

<h2>
Admin Login
</h2>

<p style="text-align:center;">
Login as Main Admin to manage all department admin accounts
and registered users. Looking for a Civil &amp; Plumbing,
Electrical, AC &amp; RO or Pest Control department login
instead? Use
<a href="index.php?page=departmental_login">Departmental Login</a>.
</p>


<?php

if (
    $admin_login_error != "" &&
    $admin_login_type == "Main Admin"
) {

?>

<div class="message error">

<?php
echo htmlspecialchars(
    $admin_login_error
);
?>

</div>

<?php } ?>


<div class="form-box">

<form method="POST">

<input
type="hidden"
name="admin_type"
value="Main Admin"
>


<label>
Main Admin Username
</label>

<input
type="text"
name="admin_username"
required
>


<label>
Password
</label>

<input
type="password"
name="admin_password"
required
>


<button
type="submit"
name="admin_login"
class="btn"
>
LOGIN AS MAIN ADMIN
</button>

</form>

<br>

<a
href="index.php?page=login"
class="btn"
>
BACK TO LOGIN
</a>

</div>

</div>

<?php } ?>


<!-- =====================================================
     DEPARTMENTAL LOGIN (Civil & Plumbing / Electrical /
     AC & RO / Pest Control admin selection)
===================================================== -->

<?php if ($page == "departmental_login") { ?>

<div class="content-box">

<h2>
Departmental Login
</h2>

<p style="text-align:center;">
Select your maintenance department administrator login
below.
</p>


<div class="login-options" style="grid-template-columns:repeat(4,1fr);">


<div class="login-option">

<h3>
Civil &amp; Plumbing Department
</h3>

<p>
Civil &amp; Plumbing complaints.
</p>

<a
href="index.php?page=civil_admin_login"
class="btn"
>
CIVIL &amp; PLUMBING LOGIN
</a>

</div>


<div class="login-option">

<h3>
Electrical Department
</h3>

<p>
Electrical maintenance complaints.
</p>

<a
href="index.php?page=electrical_admin_login"
class="btn"
>
ELECTRICAL DEPARTMENT LOGIN
</a>

</div>


<div class="login-option">

<h3>
AC &amp; RO Department
</h3>

<p>
Air Conditioner and Water Purifier complaints.
</p>

<a
href="index.php?page=acro_admin_login"
class="btn"
>
AC &amp; RO DEPARTMENT LOGIN
</a>

</div>


<div class="login-option">

<h3>
Pest Control Department
</h3>

<p>
Pest control complaints.
</p>

<a
href="index.php?page=pestcontrol_admin_login"
class="btn"
>
PEST CONTROL DEPARTMENT LOGIN
</a>

</div>


</div>

<br>

<div style="text-align:center;">

<a
href="index.php?page=login"
class="btn"
>
BACK TO LOGIN
</a>

</div>

</div>

<?php } ?>


<!-- =====================================================
     CIVIL ADMIN LOGIN
===================================================== -->

<?php if ($page == "civil_admin_login") { ?>

<div class="content-box">

<h2>
Civil &amp; Plumbing Department Login
</h2>


<?php

if (
    $admin_login_error != "" &&
    $admin_login_type == "Civil & Plumbing"
) {

?>

<div class="message error">

<?php
echo htmlspecialchars(
    $admin_login_error
);
?>

</div>

<?php } ?>


<div class="form-box">

<form method="POST">

<input
type="hidden"
name="admin_type"
value="Civil & Plumbing"
>


<label>
Civil &amp; Plumbing Department Username
</label>

<input
type="text"
name="admin_username"
required
>


<label>
Password
</label>

<input
type="password"
name="admin_password"
required
>


<button
type="submit"
name="admin_login"
class="btn"
>
LOGIN AS CIVIL &amp; PLUMBING DEPARTMENT
</button>

<br>

<a
href="index.php?page=forgot_password"
class="btn"
>
FORGOT PASSWORD
</a>

</form>

<br>

<a
href="index.php?page=departmental_login"
class="btn"
>
BACK
</a>

</div>

</div>

<?php } ?>


<!-- =====================================================
     AC AND RO ADMIN LOGIN
===================================================== -->

<?php if ($page == "acro_admin_login") { ?>

<div class="content-box">

<h2>
AC &amp; RO Department Login
</h2>


<?php

if (
    $admin_login_error != "" &&
    $admin_login_type == "AC and RO"
) {

?>

<div class="message error">

<?php
echo htmlspecialchars(
    $admin_login_error
);
?>

</div>

<?php } ?>


<div class="form-box">

<form method="POST">

<input
type="hidden"
name="admin_type"
value="AC and RO"
>


<label>
AC and RO Department Username
</label>

<input
type="text"
name="admin_username"
required
>


<label>
Password
</label>

<input
type="password"
name="admin_password"
required
>


<button
type="submit"
name="admin_login"
class="btn"
>
LOGIN AS AC &amp; RO DEPARTMENT
</button>

<br>

<a
href="index.php?page=forgot_password"
class="btn"
>
FORGOT PASSWORD
</a>

</form>

<br>

<a
href="index.php?page=departmental_login"
class="btn"
>
BACK
</a>

</div>

</div>

<?php } ?>


<!-- =====================================================
     ELECTRICAL ADMIN LOGIN
===================================================== -->

<?php if ($page == "electrical_admin_login") { ?>

<div class="content-box">

<h2>
Electrical Department Login
</h2>


<?php

if (
    $admin_login_error != "" &&
    $admin_login_type == "Electrical"
) {

?>

<div class="message error">

<?php
echo htmlspecialchars(
    $admin_login_error
);
?>

</div>

<?php } ?>


<div class="form-box">

<form method="POST">

<input
type="hidden"
name="admin_type"
value="Electrical"
>


<label>
Electrical Department Username
</label>

<input
type="text"
name="admin_username"
required
>


<label>
Password
</label>

<input
type="password"
name="admin_password"
required
>


<button
type="submit"
name="admin_login"
class="btn"
>
LOGIN AS ELECTRICAL DEPARTMENT
</button>

<br>

<a
href="index.php?page=forgot_password"
class="btn"
>
FORGOT PASSWORD
</a>

</form>

<br>

<a
href="index.php?page=departmental_login"
class="btn"
>
BACK
</a>

</div>

</div>

<?php } ?>


<!-- =====================================================
     FORGOT PASSWORD
===================================================== -->

<?php if ($page == "forgot_password") { ?>

<div class="content-box">

<h2>
Forgot Password
</h2>

<div class="form-box">

<form>

<label>
Email ID
</label>

<input
type="email"
placeholder="Enter registered email"
required
>

<button
type="submit"
class="btn"
>
SEND OTP
</button>

</form>

<br>

<a
href="index.php?page=login"
class="btn"
>
BACK TO LOGIN
</a>

</div>

</div>

<?php } ?>

<!-- =====================================================
     PEST CONTROL ADMIN LOGIN
===================================================== -->

<?php if ($page == "pestcontrol_admin_login") { ?>

<div class="content-box">

<h2>
Pest Control Department Login
</h2>


<?php

if (
    $admin_login_error != "" &&
    $admin_login_type == "Pest Control"
) {

?>

<div class="message error">

<?php
echo htmlspecialchars(
    $admin_login_error
);
?>

</div>

<?php } ?>


<div class="form-box">

<form method="POST">

<input
type="hidden"
name="admin_type"
value="Pest Control"
>


<label>
Pest Control Department Username
</label>

<input
type="text"
name="admin_username"
required
>


<label>
Password
</label>

<input
type="password"
name="admin_password"
required
>


<button
type="submit"
name="admin_login"
class="btn"
>
LOGIN AS PEST CONTROL DEPARTMENT
</button>

<br>

<a
href="index.php?page=forgot_password"
class="btn"
>
FORGOT PASSWORD
</a>

</form>

<br>

<a
href="index.php?page=departmental_login"
class="btn"
>
BACK
</a>

</div>

</div>

<?php } ?>


<!-- =====================================================
     REGISTER (admin-only - reachable directly too, but
     guarded so it always requires an admin session first)
===================================================== -->

<?php if ($page == "register") { ?>

<?php

if (!isset($_SESSION['admin_logged_in'])) {

    header("Location: index.php?page=admin_login");

    exit();
}

?>

<div class="content-box">

<h2>
Create New User Account
</h2>

<?php if ($register_message != "") { ?>

<div class="message<?php echo $register_success ? '' : ' error'; ?>">
<?php
echo htmlspecialchars(
    $register_message
);
?>
</div>

<?php } ?>


<div class="form-box">

<form method="POST">

<label>
Choose a Username
</label>

<input
type="text"
name="username"
required
>


<label>
Name & Designation
</label>

<input
type="text"
name="name_designation"
required
>


<label>
Department
</label>

<input
type="text"
name="department"
required
>


<label>
Email ID
</label>

<input
type="email"
name="email"
required
>


<label>
Mobile Number
</label>

<input
type="tel"
name="mobile"
pattern="[0-9]{10}"
maxlength="10"
required
>


<label>
Joining Date
</label>

<input
type="date"
name="joining_date"
required
>

<label>
Password
</label>

<input
type="password"
name="password"
required
>

<label>
Confirm Password
</label>

<input
type="password"
name="confirm_password"
required
>


<button
type="submit"
name="register_user"
class="btn green-btn"
>
REGISTER
</button>

</form>

</div>

</div>

<?php } ?>


<!-- =====================================================
     USER DASHBOARD
===================================================== -->

<?php if ($page == "user_dashboard") { ?>

<?php

if (
    !isset($_SESSION['user_logged_in'])
) {

    header(
        "Location: index.php?page=user_login"
    );

    exit();
}

?>


<div class="dashboard-layout">


<div class="dashboard-sidebar">

<h3>
User Dashboard
</h3>

<a
href="index.php?page=user_dashboard&view=dashboard"
class="<?php
echo $user_view == 'dashboard'
? 'active'
: '';
?>"
>
Dashboard
</a>

<a
href="index.php?page=user_dashboard&view=register_complaint"
class="<?php
echo $user_view == 'register_complaint'
? 'active'
: '';
?>"
>
Register Complaint
</a>

<a
href="index.php?page=user_dashboard&view=track_complaint"
class="<?php
echo $user_view == 'track_complaint'
? 'active'
: '';
?>"
>
Track Complaint
</a>

<a
href="index.php?page=user_dashboard&view=complaints"
class="<?php
echo $user_view == 'complaints'
? 'active'
: '';
?>"
>
Complaints
</a>

<a
href="index.php?page=user_dashboard&view=reports"
class="<?php
echo $user_view == 'reports'
? 'active'
: '';
?>"
>
Reports
</a>

<a
href="index.php?page=user_dashboard&view=feedback"
class="<?php
echo $user_view == 'feedback'
? 'active'
: '';
?>"
>
Feedback
</a>

<details
class="sidebar-operations"
<?php echo $user_view == 'change_password' ? 'open' : ''; ?>
>

<summary>
Operations
</summary>

<a
href="index.php?page=user_dashboard&view=change_password"
class="<?php
echo $user_view == 'change_password'
? 'active'
: '';
?>"
>
Change Password
</a>

</details>

<a href="index.php?logout=1">
Logout
</a>

</div>


<div class="dashboard-content">

<div class="dashboard-title">

<h2>
User Dashboard
</h2>

<p>
Welcome,
<?php
echo htmlspecialchars(
    $_SESSION['user_name_designation'] ?? $_SESSION['username']
);
?>
</p>

</div>


<!-- =====================================================
     USER DASHBOARD
===================================================== -->

<?php if ($user_view == "dashboard") { ?>

<div class="content-box">

<h2>
Dashboard Overview
</h2>

<p>
Use the menu to register complaints, track complaints,
view reports and receive administrator work updates.
</p>


<div class="report-cards">

<div class="report-card">

<h3>
Total Complaints
</h3>

<div class="report-number">
<?php
echo getUserComplaintCount();
?>
</div>

</div>


<div class="report-card">

<h3>
Pending
</h3>

<div class="report-number">
<?php
echo getUserComplaintCount('Pending');
?>
</div>

</div>


<div class="report-card">

<h3>
Working
</h3>

<div class="report-number">
<?php
echo getUserComplaintCount('Working');
?>
</div>

</div>

</div>

</div>

<?php } ?>


<!-- =====================================================
     REGISTER COMPLAINT
===================================================== -->

<?php if ($user_view == "register_complaint") { ?>

<div class="content-box">

<h2>
Register Complaint
</h2>


<?php if ($complaint_message != "") { ?>

<div class="message">

<?php
echo htmlspecialchars(
    $complaint_message
);
?>

</div>

<?php } ?>


<div class="form-box">

<form
method="POST"
enctype="multipart/form-data"
>


<h3 style="
border-left:5px solid #075b9d;
padding:12px 15px;
background:#eef7ff;
margin-bottom:20px;
">
Complaint Raised By
</h3>


<label>
Name & Designation
</label>

<input
type="text"
name="name_designation"
value="<?php
echo htmlspecialchars(
    $_SESSION['user_name_designation'] ?? $_SESSION['username']
);
?>"
required
>


<label>
Contact Number
</label>

<input
type="tel"
name="contact_number"
pattern="[0-9]{10}"
maxlength="10"
value="<?php
echo htmlspecialchars(
    $_SESSION['user_mobile'] ?? ''
);
?>"
required
>


<label>
Email
</label>

<input
type="email"
name="complaint_email"
value="<?php
echo htmlspecialchars(
    $_SESSION['user_email'] ?? ''
);
?>"
required
>


<label>
Department / Ward / Area
</label>

<select
name="department_ward_area"
required
>

<option value="">
-- Select Department / Ward / Area --
</option>


<optgroup label="Hospital Departments">

<option>Administration</option>
<option>Cardiology</option>
<option>General Medicine</option>
<option>General Surgery</option>
<option>Orthopaedics</option>
<option>Paediatrics</option>
<option>Obstetrics and Gynaecology</option>
<option>ENT</option>
<option>Ophthalmology</option>
<option>Dermatology</option>
<option>Psychiatry</option>
<option>Radiology</option>
<option>Pathology</option>
<option>Microbiology</option>
<option>Emergency</option>
<option>Laboratory</option>
<option>Pharmacy</option>
<option>Blood Bank</option>
<option>Operation Theatre</option>
<option>ICU</option>

</optgroup>


<optgroup label="Wards">

<?php

foreach (
    $ward_area_list
    as $ward
) {

?>

<option value="<?php
echo htmlspecialchars($ward);
?>">

<?php
echo htmlspecialchars($ward);
?>

</option>

<?php

}

?>

</optgroup>


<optgroup label="Hospital Areas / Facilities">

<option>OPD</option>
<option>IPD</option>
<option>Registration Counter</option>
<option>Waiting Area</option>
<option>Reception</option>
<option>Corridor</option>
<option>Staircase</option>
<option>Lift Area</option>
<option>Toilet</option>
<option>Washroom</option>
<option>Parking Area</option>
<option>Canteen</option>
<option>Store</option>
<option>Mortuary</option>
<option>Other Hospital Area</option>

</optgroup>

</select>


<label>
Department Location: Block & Floor
</label>

<input
type="text"
name="department_location"
placeholder="Example: Block A - 2nd Floor"
required
>


<h3 style="
border-left:5px solid #075b9d;
padding:12px 15px;
background:#eef7ff;
margin-top:30px;
margin-bottom:20px;
">
Complaint Details
</h3>


<label>
Service Category
</label>

<select
name="complaint_type"
required
>

<option value="">
-- Select Service Category --
</option>

<option value="Civil & Plumbing">
Civil & Plumbing
</option>

<option value="Electrical">
Electrical
</option>

<option value="AC and RO">
AC and RO
</option>

<option value="Pest Control">
Pest Control
</option>

</select>


<label>
Complaint Title
</label>

<input
type="text"
name="complaint_title"
required
>


<label>
Complaint Description
</label>

<textarea
name="description"
required
></textarea>


<label>
Upload Complaint Pictures
</label>

<input
type="file"
name="complaint_images[]"
accept="image/jpeg,image/png,image/jpg,image/webp"
multiple
>


<small>
You can select multiple pictures.
</small>


<button
type="submit"
name="submit_complaint"
class="btn"
>
SUBMIT COMPLAINT
</button>


<a
href="index.php?page=user_dashboard"
class="btn"
>
BACK TO DASHBOARD
</a>

</form>

</div>

</div>

<?php } ?>


<!-- =====================================================
     TRACK COMPLAINT
===================================================== -->

<?php if ($user_view == "track_complaint") { ?>

<div class="content-box">

<h2>
Track Complaint
</h2>


<div class="table-container">

<table>

<tr>

<th>Complaint ID</th>
<th>Service</th>
<th>Location</th>
<th>Title</th>
<th>Status</th>
<th>Assigned To</th>
<th>Work Process</th>
<th>Admin Message</th>
<th>Date</th>

</tr>


<?php

$found = false;


if (
    isset($_SESSION['complaints'])
) {

foreach (
    $_SESSION['complaints']
    as $complaint
) {

if (
    ($complaint['username'] ?? '')
    !== $_SESSION['username']
) {

continue;

}


$found = true;

?>


<tr>

<td>
<?php
echo htmlspecialchars(
    $complaint['id'] ?? ''
);
?>
</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['type'] ?? ''
);
?>
</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['department_location']
    ?? ''
);
?>
</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['complaint_title']
    ?? ''
);
?>
</td>

<td>

<span class="status">

<?php
echo htmlspecialchars(
    $complaint['status'] ?? ''
);
?>

</span>

</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['assigned_to'] ?? ''
);
?>

<br>

<?php
echo htmlspecialchars(
    $complaint['assigned_contact'] ?? ''
);
?>

</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['work_process'] ?? ''
);
?>
</td>

<td>

<?php
echo htmlspecialchars(
    $complaint['admin_message'] ?? ''
);
?>

<br>

<small>
<?php
echo htmlspecialchars(
    $complaint['admin_message_date'] ?? ''
);
?>
</small>

</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['date'] ?? ''
);
?>
</td>

</tr>


<?php

}

}


if (!$found) {

?>

<tr>

<td colspan="9">
No complaints found.
</td>

</tr>

<?php

}

?>

</table>

</div>

</div>

<?php } ?>


<!-- =====================================================
     USER COMPLAINTS
===================================================== -->

<?php if ($user_view == "complaints") { ?>

<div class="content-box">

<h2>
My Complaints
</h2>

<?php if ($delete_complaint_message != "") { ?>

<div class="message<?php echo (strpos(strtolower($delete_complaint_message), 'already') !== false || strpos(strtolower($delete_complaint_message), 'not found') !== false) ? ' error' : ''; ?>">

<?php
echo htmlspecialchars(
    $delete_complaint_message
);
?>

</div>

<?php } ?>


<div class="table-container">

<table>

<tr>

<th>Complaint ID</th>
<th>Raised By</th>
<th>Contact</th>
<th>Department / Ward / Area</th>
<th>Location</th>
<th>Service</th>
<th>Title</th>
<th>Description</th>
<th>Pictures</th>
<th>Status</th>
<th>Assigned Worker</th>
<th>Work Process</th>
<th>Admin Message</th>
<th>Action</th>

</tr>


<?php

$found = false;


if (
    isset($_SESSION['complaints'])
) {

foreach (
    $_SESSION['complaints']
    as $index => $complaint
) {

if (
    ($complaint['username'] ?? '')
    !== $_SESSION['username']
) {

continue;

}


$found = true;

?>


<tr>

<td>
<?php
echo htmlspecialchars(
    $complaint['id'] ?? ''
);
?>
</td>


<td>
<?php
echo htmlspecialchars(
    $complaint['name_designation'] ?? ''
);
?>
</td>


<td>
<?php
echo htmlspecialchars(
    $complaint['contact_number'] ?? ''
);
?>
</td>


<td>
<?php
echo htmlspecialchars(
    $complaint['department_ward_area'] ?? ''
);
?>
</td>


<td>
<?php
echo htmlspecialchars(
    $complaint['department_location'] ?? ''
);
?>
</td>


<td>
<?php
echo htmlspecialchars(
    $complaint['type'] ?? ''
);
?>
</td>


<td>
<?php
echo htmlspecialchars(
    $complaint['complaint_title'] ?? ''
);
?>
</td>


<td>
<?php
echo htmlspecialchars(
    $complaint['description'] ?? ''
);
?>
</td>


<td>

<?php

if (
    !empty($complaint['images'])
) {

?>

<div class="photo-grid">

<?php

foreach (
    $complaint['images']
    as $photo
) {

?>

<a
href="<?php
echo htmlspecialchars($photo);
?>"
target="_blank"
>

<img
src="<?php
echo htmlspecialchars($photo);
?>"
alt="Complaint Photo"
>

</a>

<?php

}

?>

</div>

<?php

} else {

echo "No pictures";

}

?>

</td>


<td>

<span class="status">

<?php
echo htmlspecialchars(
    $complaint['status'] ?? ''
);
?>

</span>

</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['assigned_to'] ?? ''
);
?>

<br>

<?php
echo htmlspecialchars(
    $complaint['assigned_contact'] ?? ''
);
?>

</td>


<td>
<?php
echo htmlspecialchars(
    $complaint['work_process'] ?? ''
);
?>
</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['admin_message'] ?? ''
);
?>

<br>

<small>
<?php
echo htmlspecialchars(
    $complaint['admin_message_date'] ?? ''
);
?>
</small>

</td>


<td>

<?php if (empty($complaint['assigned_to'])) { ?>

<form
method="POST"
onsubmit="return confirm('Delete this complaint? This cannot be undone.');"
>

<input
type="hidden"
name="complaint_index"
value="<?php echo $index; ?>"
>

<button
type="submit"
name="delete_complaint"
class="btn red-btn"
>
DELETE
</button>

</form>

<?php } else { ?>

<small>
Work already assigned
</small>

<?php } ?>

</td>

</tr>


<?php

}

}


if (!$found) {

?>

<tr>

<td colspan="14">
No complaints registered yet.
</td>

</tr>

<?php

}

?>

</table>

</div>

</div>

<?php } ?>


<!-- =====================================================
     USER REPORTS
===================================================== -->

<?php if ($user_view == "reports") { ?>

<?php

$report_period =
    $_GET['period'] ?? 'monthly';
    if (
    !in_array(
        $report_period,
        [
            'daily',
            'weekly',
            'monthly'
        ]
    )
) {

    $report_period = 'monthly';
}


$total_report =
    getReportCount(
        $report_period,
        null,
        null,
        $_SESSION['username']
    );

$pending_report =
    getReportCount(
        $report_period,
        'Pending',
        null,
        $_SESSION['username']
    );

$working_report =
    getReportCount(
        $report_period,
        'Working',
        null,
        $_SESSION['username']
    );

$delayed_report =
    getReportCount(
        $report_period,
        'Delayed',
        null,
        $_SESSION['username']
    );

$resolved_report =
    getReportCount(
        $report_period,
        'Resolved',
        null,
        $_SESSION['username']
    );

$closed_report =
    getReportCount(
        $report_period,
        'Closed',
        null,
        $_SESSION['username']
    );

?>

<div class="content-box">

<h2>
Complaint Reports
</h2>


<div class="report-period">

<a href="index.php?page=user_dashboard&view=reports&period=daily">
Daily Report
</a>

<a href="index.php?page=user_dashboard&view=reports&period=weekly">
Weekly Report
</a>

<a href="index.php?page=user_dashboard&view=reports&period=monthly">
Monthly Report
</a>

</div>


<h3>
<?php
echo ucfirst(
    $report_period
);
?>
 Report
</h3>


<div class="report-cards">

<div class="report-card">

<h3>
Total Complaints
</h3>

<div class="report-number">
<?php
echo $total_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Pending
</h3>

<div class="report-number">
<?php
echo $pending_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Working
</h3>

<div class="report-number">
<?php
echo $working_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Delayed
</h3>

<div class="report-number">
<?php
echo $delayed_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Resolved
</h3>

<div class="report-number">
<?php
echo $resolved_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Closed
</h3>

<div class="report-number">
<?php
echo $closed_report;
?>
</div>

</div>

</div>


<h3>
360° Status Percentage
</h3>


<div class="circular-report-box">

<?php

statusCircle(
    'Pending',
    $pending_report,
    $total_report,
    'circle-pending'
);

statusCircle(
    'Working',
    $working_report,
    $total_report,
    'circle-working'
);

statusCircle(
    'Delayed',
    $delayed_report,
    $total_report,
    'circle-delayed'
);

statusCircle(
    'Resolved',
    $resolved_report,
    $total_report,
    'circle-resolved'
);

statusCircle(
    'Closed',
    $closed_report,
    $total_report,
    'circle-closed'
);

?>

</div>


<h3>
Detailed Status Report
</h3>

<p>
Every complaint you have raised in the
<?php echo strtolower($report_period); ?>
period, listed under its current status with the assigned
worker, work process, delay reason (if any) and the full
history of updates.
</p>

<?php
renderDetailedStatusReport(
    getReportComplaints($report_period, null, $_SESSION['username'])
);
?>

</div>

<?php } ?>


<!-- =====================================================
     USER FEEDBACK (rating + message, submits for real)
===================================================== -->

<?php if ($user_view == "feedback") { ?>

<div class="content-box">

<h2>
Feedback
</h2>

<?php if ($feedback_message != "") { ?>

<div class="message<?php echo (strpos(strtolower($feedback_message), 'please') !== false) ? ' error' : ''; ?>">

<?php
echo htmlspecialchars(
    $feedback_message
);
?>

</div>

<?php } ?>

<div class="form-box">

<form method="POST">

<label>
Rate Your Experience
</label>

<div class="rating-group">

<?php for ($star = 5; $star >= 1; $star--) { ?>

<input
type="radio"
id="rating<?php echo $star; ?>"
name="rating"
value="<?php echo $star; ?>"
required
>

<label
for="rating<?php echo $star; ?>"
class="star-label"
>&#9733;</label>

<?php } ?>

</div>


<label>
Your Feedback
</label>

<textarea
name="feedback_text"
placeholder="Share your experience with the complaint system"
required
></textarea>


<button
type="submit"
name="submit_feedback"
class="btn"
>
SUBMIT FEEDBACK
</button>

</form>

</div>


<?php

$all_feedback_data = loadJsonData($feedback_file);

$my_feedback = array_values(
    array_filter(
        $all_feedback_data,
        function ($f) {
            return ($f['username'] ?? '') === $_SESSION['username'];
        }
    )
);

?>

<?php if (count($my_feedback) > 0) { ?>

<h3 style="margin-top:30px;">
Your Previous Feedback
</h3>

<div class="table-container">

<table>

<tr>
<th>Rating</th>
<th>Feedback</th>
<th>Date</th>
</tr>

<?php foreach (array_reverse($my_feedback) as $f) { ?>

<tr>

<td>
<?php
echo str_repeat('&#9733;', intval($f['rating'] ?? 0));
?>
</td>

<td>
<?php
echo htmlspecialchars($f['message'] ?? '');
?>
</td>

<td>
<?php
echo htmlspecialchars($f['date'] ?? '');
?>
</td>

</tr>

<?php } ?>

</table>

</div>

<?php } ?>

</div>

<?php } ?>


<!-- =====================================================
     OPERATIONS - CHANGE PASSWORD
===================================================== -->

<?php if ($user_view == "change_password") { ?>

<div class="content-box">

<h2>
Change Password
</h2>

<?php if ($change_password_message != "") { ?>

<div class="message<?php echo (stripos($change_password_message, 'success') === false) ? ' error' : ''; ?>">

<?php
echo htmlspecialchars(
    $change_password_message
);
?>

</div>

<?php } ?>

<div class="form-box">

<form method="POST">

<label>
Current Password
</label>

<input
type="password"
name="current_password"
required
>


<label>
New Password
</label>

<input
type="password"
name="new_password"
required
>


<label>
Confirm New Password
</label>

<input
type="password"
name="confirm_new_password"
required
>


<button
type="submit"
name="change_password_submit"
class="btn"
>
UPDATE PASSWORD
</button>

</form>

</div>

</div>

<?php } ?>


</div>

</div>

<?php } ?>


<!-- =====================================================
     ADMIN DASHBOARD
===================================================== -->

<?php if ($page == "admin_dashboard") { ?>

<?php

if (
    !isset($_SESSION['admin_logged_in'])
) {

    header(
        "Location: index.php?page=admin_login"
    );

    exit();
}


$current_admin_type =
    $_SESSION['admin_type'] ?? '';


$is_main_admin =
    !empty($_SESSION['is_main_admin']);


/*
========================================================
ADMIN DEPARTMENT FILTER
Main Admin sees every department (no filter); a department
admin only sees their own department's complaints, exactly
as before.
========================================================
*/

$admin_filter =
    $is_main_admin
    ? null
    : $current_admin_type;

?>


<div class="dashboard-layout">


<div class="dashboard-sidebar">

<h3>
<?php
echo htmlspecialchars(
    $current_admin_type
);
?>
<?php echo $is_main_admin ? '' : ' Department'; ?>
</h3>


<a
href="index.php?page=admin_dashboard&view=dashboard"
class="<?php
echo $admin_view == 'dashboard'
? 'active'
: '';
?>"
>
Dashboard
</a>


<?php if ($is_main_admin) { ?>

<a
href="index.php?page=admin_dashboard&view=manage_admins"
class="<?php
echo $admin_view == 'manage_admins'
? 'active'
: '';
?>"
>
Manage Admins
</a>

<?php } ?>


<a
href="index.php?page=admin_dashboard&view=register_user"
class="<?php
echo $admin_view == 'register_user'
? 'active'
: '';
?>"
>
Register User
</a>


<a
href="index.php?page=admin_dashboard&view=track"
class="<?php
echo $admin_view == 'track'
? 'active'
: '';
?>"
>
Track Complaint
</a>


<a
href="index.php?page=admin_dashboard&view=complaints"
class="<?php
echo $admin_view == 'complaints'
? 'active'
: '';
?>"
>
Complaints
</a>


<a
href="index.php?page=admin_dashboard&view=reports"
class="<?php
echo $admin_view == 'reports'
? 'active'
: '';
?>"
>
Reports
</a>


<a
href="index.php?page=admin_dashboard&view=feedback"
class="<?php
echo $admin_view == 'feedback'
? 'active'
: '';
?>"
>
Feedback
</a>


<?php if (!$is_main_admin) { ?>

<details
class="sidebar-operations"
<?php echo $admin_view == 'change_password' ? 'open' : ''; ?>
>

<summary>
Operations
</summary>

<a
href="index.php?page=admin_dashboard&view=change_password"
class="<?php
echo $admin_view == 'change_password'
? 'active'
: '';
?>"
>
Change Password
</a>

</details>

<?php } ?>


<a href="index.php?logout=1">
Logout
</a>

</div>


<div class="dashboard-content">


<div class="dashboard-title">

<h2>
<?php
echo htmlspecialchars(
    $current_admin_type
);
?>
<?php echo $is_main_admin ? '' : ' Department Login'; ?>
</h2>

<p>
Welcome,
<?php
echo htmlspecialchars(
    $_SESSION['admin_username']
);
?>
</p>

</div>


<!-- =====================================================
     ADMIN DASHBOARD HOME
===================================================== -->

<?php if ($admin_view == "dashboard") { ?>

<div class="content-box">

<h2>
Complaint Overview
</h2>

<p>
<?php if ($is_main_admin) { ?>
As Main Admin you can see complaints across every
department, manage all department admin accounts and
register new user accounts.
<?php } else { ?>
New complaints are routed according to their selected
service category. The <?php echo htmlspecialchars($current_admin_type); ?>
department administrator can assign work, update status and send
work-process information to the user.
<?php } ?>
</p>


<?php

$new_notifications = 0;

if (
    isset($_SESSION['notifications'])
) {

foreach (
    $_SESSION['notifications']
    as $notification
) {

if (
    !$notification['read'] &&
    strcasecmp(
        $notification['type'],
        'New Complaint'
    ) === 0
) {

$new_notifications++;

}

}

}

?>


<div class="notification">

<strong>
New Complaint Notifications:
</strong>

<?php
echo $new_notifications;
?>

</div>


<div class="report-cards">

<div class="report-card">

<h3>Total</h3>

<div class="report-number">

<?php
echo getComplaintCount(
    null,
    $admin_filter
);
?>

</div>

</div>


<div class="report-card">

<h3>Pending</h3>

<div class="report-number">

<?php
echo getComplaintCount(
    'Pending',
    $admin_filter
);
?>

</div>

</div>


<div class="report-card">

<h3>Working</h3>

<div class="report-number">

<?php
echo getComplaintCount(
    'Working',
    $admin_filter
);
?>

</div>

</div>


<div class="report-card">

<h3>Delayed</h3>

<div class="report-number">

<?php
echo getComplaintCount(
    'Delayed',
    $admin_filter
);
?>

</div>

</div>


<div class="report-card">

<h3>Resolved</h3>

<div class="report-number">

<?php
echo getComplaintCount(
    'Resolved',
    $admin_filter
);
?>

</div>

</div>


<div class="report-card">

<h3>Closed</h3>

<div class="report-number">

<?php
echo getComplaintCount(
    'Closed',
    $admin_filter
);
?>

</div>

</div>

</div>

</div>

<?php } ?>


<!-- =====================================================
     MANAGE ADMINS (MAIN ADMIN ONLY)
===================================================== -->

<?php if ($admin_view == "manage_admins" && $is_main_admin) { ?>

<div class="content-box">

<h2>
Manage Department Admins
</h2>

<?php if (!empty($admin_manage_message)) { ?>

<div class="message<?php echo (stripos($admin_manage_message, 'success') === false) ? ' error' : ''; ?>">
<?php echo htmlspecialchars($admin_manage_message); ?>
</div>

<?php } ?>

<h3>
Add New Department Admin
</h3>

<div class="form-box">

<form method="POST">

<label>
Department
</label>

<select
name="new_admin_department"
required
>

<option value="">-- Select Department --</option>
<option value="Civil & Plumbing">Civil & Plumbing</option>
<option value="Electrical">Electrical</option>
<option value="AC and RO">AC and RO</option>
<option value="Pest Control">Pest Control</option>

</select>


<label>
Username
</label>

<input
type="text"
name="new_admin_username"
required
>


<label>
Password
</label>

<input
type="password"
name="new_admin_password"
required
>


<label>
Confirm Password
</label>

<input
type="password"
name="new_admin_confirm_password"
required
>


<button
type="submit"
name="add_admin"
class="btn green-btn"
>
ADD ADMIN
</button>

</form>

</div>


<h3 style="margin-top:30px;">
Existing Department Admins
</h3>

<div class="table-container">

<table>

<tr>
<th>Department</th>
<th>Username</th>
<th>Created On</th>
<th>Edit</th>
<th>Delete</th>
</tr>

<?php

$all_admins_list = loadJsonData($admins_file);

if (count($all_admins_list) > 0) {

foreach ($all_admins_list as $adm) {

?>

<tr>

<td>
<?php echo htmlspecialchars($adm['department'] ?? ''); ?>
</td>

<td>
<?php echo htmlspecialchars($adm['username'] ?? ''); ?>
</td>

<td>
<?php echo htmlspecialchars($adm['created_on'] ?? ''); ?>
</td>

<td>

<details>

<summary style="cursor:pointer;color:#075b9d;font-weight:bold;">
Edit
</summary>

<form method="POST" style="margin-top:10px;">

<input
type="hidden"
name="admin_id"
value="<?php echo htmlspecialchars($adm['id'] ?? ''); ?>"
>

<label>
Department
</label>

<input
type="text"
name="edit_admin_department"
value="<?php echo htmlspecialchars($adm['department'] ?? ''); ?>"
required
>

<label>
Username
</label>

<input
type="text"
name="edit_admin_username"
value="<?php echo htmlspecialchars($adm['username'] ?? ''); ?>"
required
>

<label>
New Password (leave blank to keep current)
</label>

<input
type="password"
name="edit_admin_password"
>

<button
type="submit"
name="update_admin"
class="btn"
>
SAVE CHANGES
</button>

</form>

</details>

</td>

<td>

<form
method="POST"
onsubmit="return confirm('Delete this admin account?');"
>

<input
type="hidden"
name="admin_id"
value="<?php echo htmlspecialchars($adm['id'] ?? ''); ?>"
>

<button
type="submit"
name="delete_admin"
class="btn red-btn"
>
DELETE
</button>

</form>

</td>

</tr>

<?php

}

} else {

?>

<tr>
<td colspan="5">
No department admins found.
</td>
</tr>

<?php

}

?>

</table>

</div>

</div>

<?php } ?>


<!-- =====================================================
     REGISTER USER (ANY ADMIN)
===================================================== -->

<?php if ($admin_view == "register_user") { ?>

<div class="content-box">

<h2>
Register New User
</h2>

<?php if ($register_message != "") { ?>

<div class="message<?php echo $register_success ? '' : ' error'; ?>">
<?php echo htmlspecialchars($register_message); ?>
</div>

<?php } ?>

<div class="form-box">

<form method="POST">

<label>
Choose a Username
</label>

<input
type="text"
name="username"
required
>


<label>
Name & Designation
</label>

<input
type="text"
name="name_designation"
required
>


<label>
Department
</label>

<input
type="text"
name="department"
required
>


<label>
Email ID
</label>

<input
type="email"
name="email"
required
>


<label>
Mobile Number
</label>

<input
type="tel"
name="mobile"
pattern="[0-9]{10}"
maxlength="10"
required
>


<label>
Joining Date
</label>

<input
type="date"
name="joining_date"
required
>


<label>
Password
</label>

<input
type="password"
name="password"
required
>


<label>
Confirm Password
</label>

<input
type="password"
name="confirm_password"
required
>


<button
type="submit"
name="register_user"
class="btn green-btn"
>
REGISTER USER
</button>

</form>

</div>


<?php if ($is_main_admin) { ?>

<h3 style="margin-top:30px;">
Existing User ID Records
</h3>

<?php if (!empty($user_manage_message)) { ?>

<div class="message<?php echo (stripos($user_manage_message, 'success') === false) ? ' error' : ''; ?>">
<?php echo htmlspecialchars($user_manage_message); ?>
</div>

<?php } ?>

<div class="table-container">

<table>

<tr>
<th>Username</th>
<th>Name &amp; Designation</th>
<th>Department</th>
<th>Email</th>
<th>Mobile</th>
<th>Joining Date</th>
<th>Registered By</th>
<th>Registered On</th>
<th>Delete</th>
</tr>

<?php

$all_registered_users = loadJsonData($users_file);

if (count($all_registered_users) > 0) {

foreach ($all_registered_users as $reg_user) {

?>

<tr>

<td><?php echo htmlspecialchars($reg_user['username'] ?? ''); ?></td>
<td><?php echo htmlspecialchars($reg_user['name_designation'] ?? ''); ?></td>
<td><?php echo htmlspecialchars($reg_user['department'] ?? ''); ?></td>
<td><?php echo htmlspecialchars($reg_user['email'] ?? ''); ?></td>
<td><?php echo htmlspecialchars($reg_user['mobile'] ?? ''); ?></td>
<td><?php echo htmlspecialchars($reg_user['joining_date'] ?? ''); ?></td>
<td><?php echo htmlspecialchars($reg_user['registered_by'] ?? ''); ?></td>
<td><?php echo htmlspecialchars($reg_user['registered_on'] ?? ''); ?></td>

<td>

<form
method="POST"
onsubmit="return confirm('Delete this user account? This cannot be undone.');"
>

<input
type="hidden"
name="username"
value="<?php echo htmlspecialchars($reg_user['username'] ?? ''); ?>"
>

<button
type="submit"
name="delete_user"
class="btn red-btn"
>
DELETE
</button>

</form>

</td>

</tr>

<?php

}

} else {

?>

<tr>
<td colspan="9">
No registered users found.
</td>
</tr>

<?php

}

?>

</table>

</div>

<?php } ?>

</div>

<?php } ?>


<!-- =====================================================
     ADMIN TRACK
===================================================== -->

<?php if ($admin_view == "track") { ?>

<div class="content-box">

<h2>
Track Complaints
</h2>


<div class="table-container">

<table>

<tr>

<th>Complaint ID</th>
<th>User</th>
<th>Service</th>
<th>Location</th>
<th>Title</th>
<th>Status</th>
<th>Assigned To</th>
<th>Date</th>

</tr>


<?php

$found = false;


if (
    isset($_SESSION['complaints'])
) {

foreach (
    $_SESSION['complaints']
    as $complaint
) {


if (
    $admin_filter !== null &&
    strcasecmp(
        $complaint['type'] ?? '',
        $admin_filter
    ) !== 0
) {

continue;

}


$found = true;

?>


<tr>

<td>
<?php
echo htmlspecialchars(
    $complaint['id'] ?? ''
);
?>
</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['username'] ?? ''
);
?>
</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['type'] ?? ''
);
?>
</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['department_location']
    ?? ''
);
?>
</td>

<td>
<?php
echo htmlspecialchars(
    $complaint['complaint_title']
    ?? ''
);
?>
</td>

<td>

<span class="status">

<?php
echo htmlspecialchars(
    $complaint['status'] ?? ''
);
?>

</span>

</td>

<td>

<?php
echo htmlspecialchars(
    $complaint['assigned_to'] ?? ''
);
?>

<br>

<?php
echo htmlspecialchars(
    $complaint['assigned_contact'] ?? ''
);
?>

</td>

<td>

<?php
echo htmlspecialchars(
    $complaint['date'] ?? ''
);
?>

</td>

</tr>


<?php

}

}


if (!$found) {

?>

<tr>

<td colspan="8">
No complaints registered for this department.
</td>

</tr>

<?php

}

?>

</table>

</div>

</div>

<?php } ?>


<!-- =====================================================
     ADMIN COMPLAINTS
===================================================== -->

<?php if ($admin_view == "complaints") { ?>

<div class="content-box">

<h2>
Registered <?php
echo $admin_filter !== null
? htmlspecialchars($admin_filter)
: 'All Department';
?> Complaints
</h2>


<?php if ($admin_update_message != "") { ?>

<div class="message
<?php
if (
    strpos(
        strtolower(
            $admin_update_message
        ),
        'please'
    ) !== false
) {
    echo ' error';
}
?>
">

<?php
echo htmlspecialchars(
    $admin_update_message
);
?>

</div>

<?php } ?>


<div class="table-container">

<table>

<tr>

<th>Complaint ID</th>
<th>User</th>
<th>Name</th>
<th>Contact</th>
<th>Email</th>
<th>Location</th>
<th>Title</th>
<th>Description</th>
<th>Pictures</th>
<th>Status</th>
<th>Assign / Update</th>

</tr>


<?php

$found = false;


if (
    isset($_SESSION['complaints'])
) {

foreach (
    $_SESSION['complaints']
    as $index => $complaint
) {


if (
    $admin_filter !== null &&
    strcasecmp(
        $complaint['type'] ?? '',
        $admin_filter
    ) !== 0
) {

continue;

}


$found = true;

?>


<tr>

<td>

<strong>

<?php
echo htmlspecialchars(
    $complaint['id'] ?? ''
);
?>

</strong>

</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['username'] ?? ''
);
?>

</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['name_designation']
    ?? ''
);
?>

</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['contact_number']
    ?? ''
);
?>

</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['email'] ?? ''
);
?>

</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['department_location']
    ?? ''
);
?>

<br>

<small>

<?php
echo htmlspecialchars(
    $complaint['department_ward_area']
    ?? ''
);
?>

</small>

</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['complaint_title']
    ?? ''
);
?>

</td>


<td>

<?php
echo htmlspecialchars(
    $complaint['description']
    ?? ''
);
?>

</td>


<td>

<?php

if (
    !empty($complaint['images'])
) {

?>

<div class="photo-grid">

<?php

foreach (
    $complaint['images']
    as $photo
) {

?>

<a
href="<?php
echo htmlspecialchars($photo);
?>"
target="_blank"
>

<img
src="<?php
echo htmlspecialchars($photo);
?>"
alt="Complaint Photo"
>

</a>

<?php

}

?>

</div>

<?php

} else {

echo "No pictures";

}

?>

</td>


<td>

<span class="status">

<?php
echo htmlspecialchars(
    $complaint['status'] ?? ''
);
?>

</span>

<br><br>

<?php

if (
    !empty($complaint['assigned_to'])
) {

?>

<strong>
Assigned:
</strong>

<br>

<?php
echo htmlspecialchars(
    $complaint['assigned_to']
);
?>

<?php

}

?>

</td>


<td>

<div class="assignment-box">

<form method="POST">

<input
type="hidden"
name="complaint_index"
value="<?php
echo $index;
?>"
>


<label>
Assign Work To
</label>

<input
type="text"
name="assigned_to"
placeholder="Worker name"
value="<?php
echo htmlspecialchars(
    $complaint['assigned_to'] ?? ''
);
?>"
required
>


<label>
Worker Contact
</label>

<input
type="tel"
name="assigned_contact"
placeholder="Worker contact number"
value="<?php
echo htmlspecialchars(
    $complaint['assigned_contact'] ?? ''
);
?>"
required
>


<label>
Work Process
</label>

<textarea
name="work_process"
placeholder="Enter current work process"
><?php
echo htmlspecialchars(
    $complaint['work_process'] ?? ''
);
?></textarea>


<label>
Status
</label>

<select
name="status"
class="status-select"
required
>

<option
value="Pending"
<?php
if (
    ($complaint['status'] ?? '')
    === 'Pending'
) {
    echo 'selected';
}
?>
>
Pending
</option>


<option
value="Working"
<?php
if (
    ($complaint['status'] ?? '')
    === 'Working'
) {
    echo 'selected';
}
?>
>
Working
</option>


<option
value="Delayed"
<?php
if (
    ($complaint['status'] ?? '')
    === 'Delayed'
) {
    echo 'selected';
}
?>
>
Delayed
</option>


<option
value="Resolved"
<?php
if (
    ($complaint['status'] ?? '')
    === 'Resolved'
) {
    echo 'selected';
}
?>
>
Resolved
</option>


<option
value="Closed"
<?php
if (
    ($complaint['status'] ?? '')
    === 'Closed'
) {
    echo 'selected';
}
?>
>
Closed
</option>

</select>


<label>
Delay Reason
</label>

<textarea
name="delay_reason"
placeholder="Required only when status is Delayed"
><?php
echo htmlspecialchars(
    $complaint['delay_reason'] ?? ''
);
?></textarea>


<label>
Message to User
</label>

<textarea
name="admin_message"
placeholder="Message sent to the user"
></textarea>


<button
type="submit"
name="update_complaint"
class="btn green-btn"
>
UPDATE & NOTIFY USER
</button>

</form>

</div>

</td>

</tr>


<?php

}

}


if (!$found) {

?>

<tr>

<td colspan="11">
No complaints available for this department.
</td>

</tr>

<?php

}

?>

</table>

</div>

</div>

<?php } ?>


<!-- =====================================================
     ADMIN REPORTS
===================================================== -->

<?php if ($admin_view == "reports") { ?>

<?php

$report_period =
    $_GET['period'] ?? 'monthly';


if (
    !in_array(
        $report_period,
        [
            'daily',
            'weekly',
            'monthly'
        ]
    )
) {

    $report_period = 'monthly';
}


$total_report =
    getReportCount(
        $report_period,
        null,
        $admin_filter
    );

$pending_report =
    getReportCount(
        $report_period,
        'Pending',
        $admin_filter
    );

$working_report =
    getReportCount(
        $report_period,
        'Working',
        $admin_filter
    );

$delayed_report =
    getReportCount(
        $report_period,
        'Delayed',
        $admin_filter
    );

$resolved_report =
    getReportCount(
        $report_period,
        'Resolved',
        $admin_filter
    );

$closed_report =
    getReportCount(
        $report_period,
        'Closed',
        $admin_filter
    );

?>

<div class="content-box">

<h2>
<?php
echo $admin_filter !== null
? htmlspecialchars($admin_filter)
: 'All Department';
?>
 Complaint Reports
</h2>


<div class="report-period">

<a href="index.php?page=admin_dashboard&view=reports&period=daily">
Daily Report
</a>

<a href="index.php?page=admin_dashboard&view=reports&period=weekly">
Weekly Report
</a>

<a href="index.php?page=admin_dashboard&view=reports&period=monthly">
Monthly Report
</a>

</div>


<h3>

<?php
echo ucfirst(
    $report_period
);
?>

 Report

</h3>


<div class="report-cards">

<div class="report-card">

<h3>
Total Complaints
</h3>

<div class="report-number">
<?php
echo $total_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Pending
</h3>

<div class="report-number">
<?php
echo $pending_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Working
</h3>

<div class="report-number">
<?php
echo $working_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Delayed
</h3>

<div class="report-number">
<?php
echo $delayed_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Resolved
</h3>

<div class="report-number">
<?php
echo $resolved_report;
?>
</div>

</div>


<div class="report-card">

<h3>
Closed
</h3>

<div class="report-number">
<?php
echo $closed_report;
?>
</div>

</div>

</div>


<h3>
360° Status Percentage
</h3>


<div class="circular-report-box">

<?php

statusCircle(
    'Pending',
    $pending_report,
    $total_report,
    'circle-pending'
);

statusCircle(
    'Working',
    $working_report,
    $total_report,
    'circle-working'
);

statusCircle(
    'Delayed',
    $delayed_report,
    $total_report,
    'circle-delayed'
);

statusCircle(
    'Resolved',
    $resolved_report,
    $total_report,
    'circle-resolved'
);

statusCircle(
    'Closed',
    $closed_report,
    $total_report,
    'circle-closed'
);

?>

</div>


<div class="content-box"
style="margin-top:25px;">

<h3>
Report Explanation
</h3>

<p>
The circular charts represent the percentage of complaints
for each status during the selected period.
The complete circle represents 360 degrees.
Different colors identify Pending, Working, Delayed,
Resolved and Closed complaints.
</p>

</div>


<h3 style="margin-top:25px;">
Detailed Status Report
</h3>

<p>
Every
<?php echo $admin_filter !== null ? htmlspecialchars($admin_filter) . ' ' : ''; ?>
complaint
in the <?php echo strtolower($report_period); ?> period, listed
under its current status with the assigned worker, worker
contact number, work process, delay reason (if any) and the
complete history of every status change made on that complaint.
</p>

<?php
renderDetailedStatusReport(
    getReportComplaints($report_period, $admin_filter)
);
?>

</div>

<?php } ?>


<!-- =====================================================
     ADMIN FEEDBACK (VIEW + DELETE - admin cannot add or
     edit entries, but can remove old feedback records)
===================================================== -->

<?php if ($admin_view == "feedback") { ?>

<div class="content-box">

<h2>
User Feedback
</h2>

<p>
This section is for viewing feedback and ratings submitted by
hospital staff about the complaint management system. Feedback
can only be submitted by users; the administrator can view it
here and delete old entries, but cannot add or edit them.
</p>

<?php if ($feedback_delete_message != "") { ?>

<div class="message<?php echo (strpos(strtolower($feedback_delete_message), 'not found') !== false) ? ' error' : ''; ?>">

<?php
echo htmlspecialchars(
    $feedback_delete_message
);
?>

</div>

<?php } ?>

<?php

$all_feedback_admin = loadJsonData($feedback_file);
$feedback_total = count($all_feedback_admin);
$feedback_sum = 0;

foreach ($all_feedback_admin as $fb) {
    $feedback_sum += intval($fb['rating'] ?? 0);
}

$feedback_avg = $feedback_total > 0
    ? round($feedback_sum / $feedback_total, 1)
    : 0;

?>

<div class="report-cards" style="grid-template-columns:repeat(2,1fr);max-width:600px;">

<div class="report-card">

<h3>
Total Feedback Received
</h3>

<div class="report-number">
<?php echo $feedback_total; ?>
</div>

</div>

<div class="report-card">

<h3>
Average Rating
</h3>

<div class="report-number">
<?php echo $feedback_avg; ?> / 5
</div>

</div>

</div>


<div class="table-container" style="margin-top:25px;">

<table>

<tr>
<th>Username</th>
<th>Name</th>
<th>Rating</th>
<th>Feedback</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php if ($feedback_total > 0) { ?>

<?php foreach (array_reverse($all_feedback_admin, true) as $findex => $fb) { ?>

<tr>

<td>
<?php echo htmlspecialchars($fb['username'] ?? ''); ?>
</td>

<td>
<?php echo htmlspecialchars($fb['name'] ?? ''); ?>
</td>

<td>
<?php echo str_repeat('&#9733;', intval($fb['rating'] ?? 0)); ?>
</td>

<td>
<?php echo htmlspecialchars($fb['message'] ?? ''); ?>
</td>

<td>
<?php echo htmlspecialchars($fb['date'] ?? ''); ?>
</td>

<td>

<form
method="POST"
onsubmit="return confirm('Delete this feedback entry?');"
>

<input
type="hidden"
name="feedback_index"
value="<?php echo $findex; ?>"
>

<button
type="submit"
name="delete_feedback"
class="btn red-btn"
>
DELETE
</button>

</form>

</td>

</tr>

<?php } ?>

<?php } else { ?>

<tr>
<td colspan="6">
No feedback received yet.
</td>
</tr>

<?php } ?>

</table>

</div>

</div>

<?php } ?>


<!-- =====================================================
     OPERATIONS - CHANGE PASSWORD (DEPARTMENT ADMINS ONLY)
===================================================== -->

<?php if ($admin_view == "change_password" && !$is_main_admin) { ?>

<div class="content-box">

<h2>
Change Password
</h2>

<?php if ($admin_change_password_message != "") { ?>

<div class="message<?php echo (stripos($admin_change_password_message, 'success') === false) ? ' error' : ''; ?>">

<?php
echo htmlspecialchars(
    $admin_change_password_message
);
?>

</div>

<?php } ?>

<div class="form-box">

<form method="POST">

<label>
Current Password
</label>

<input
type="password"
name="admin_current_password"
required
>


<label>
New Password
</label>

<input
type="password"
name="admin_new_password"
required
>


<label>
Confirm New Password
</label>

<input
type="password"
name="admin_confirm_new_password"
required
>


<button
type="submit"
name="admin_change_password_submit"
class="btn"
>
UPDATE PASSWORD
</button>

</form>

</div>

</div>

<?php } ?>


</div>

</div>

<?php } ?>


</main>


<!-- =====================================================
     FOOTER
===================================================== -->

<footer class="footer">

<p>
© 2026 AIIMS Raipur
</p>

<p>
Hospital Upkeep Complaint Management System
</p>

</footer>


<!-- =====================================================
     DELAY REASON JAVASCRIPT
===================================================== -->

<script>

document.addEventListener(
    "DOMContentLoaded",
    function() {

        const selects =
            document.querySelectorAll(
                ".status-select"
            );


        selects.forEach(
            function(select) {

                const form =
                    select.closest("form");

                if (!form) {
                    return;
                }


                const reason =
                    form.querySelector(
                        '[name="delay_reason"]'
                    );


                function updateReason() {

                    if (!reason) {
                        return;
                    }


                    if (
                        select.value ===
                        "Delayed"
                    ) {

                        reason.required =
                            true;

                        reason.placeholder =
                            "Enter reason for delay";

                        reason.style.background =
                            "#fff4f4";

                    } else {

                        reason.required =
                            false;

                        reason.value =
                            "";

                        reason.placeholder =
                            "Not required unless status is Delayed";

                        reason.style.background =
                            "white";
                    }
                }


                updateReason();


                select.addEventListener(
                    "change",
                    updateReason
                );

            }
        );

    }
);

</script>


<!-- =====================================================
     LOGIN TABS JAVASCRIPT
===================================================== -->

<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {

        var loginTabButtons =
            document.querySelectorAll(".login-tab-btn");

        loginTabButtons.forEach(function (btn) {

            btn.addEventListener("click", function () {

                var target = btn.getAttribute("data-target");

                document.querySelectorAll(".login-tab-btn").forEach(function (b) {
                    b.classList.remove("active");
                });

                document.querySelectorAll(".login-tab-panel").forEach(function (p) {
                    p.style.display = "none";
                });

                btn.classList.add("active");

                var panel = document.getElementById(target);

                if (panel) {
                    panel.style.display = "block";
                }
            });
        });

    }
);

</script>


</body>

</html>