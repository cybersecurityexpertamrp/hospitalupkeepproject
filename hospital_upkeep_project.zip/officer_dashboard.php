<?php
session_start();
include_once "db.php";

if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}

$sql = "SELECT * FROM complaints ORDER BY complaint_id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Officer Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<h1>Officer Dashboard</h1>

<h2>Complaints</h2>

<table border="1" cellpadding="10">

<tr>
    <th>Complaint ID</th>
    <th>Name</th>
    <th>Ward/Area</th>
    <th>Title</th>
    <th>Description</th>
    <th>Status</th>
</tr>

<?php while ($row = $result->fetch_assoc()) { ?>

<tr>

<td>
<?php echo htmlspecialchars($row["complaint_id"]); ?>
</td>

<td>
<?php echo htmlspecialchars($row["name"]); ?>
</td>

<td>
<?php echo htmlspecialchars($row["ward_area"]); ?>
</td>

<td>
<?php echo htmlspecialchars($row["complaint_title"]); ?>
</td>

<td>
<?php echo htmlspecialchars($row["complaint_description"]); ?>
</td>

<td>
<?php echo htmlspecialchars($row["status"]); ?>
</td>

</tr>

<?php } ?>

</table>

<br>

<a href="admin_dashboard.php">Back to Admin Dashboard</a>

</body>
</html>