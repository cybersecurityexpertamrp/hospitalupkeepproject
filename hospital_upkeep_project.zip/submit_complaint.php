<?php

include_once "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST["name"];
    $designation = $_POST["designation"];
    $mobile = $_POST["mobile"];
    $email = $_POST["email"];
    $location = $_POST["location"];
    $block = $_POST["block"];
    $category = $_POST["category"];
    $description = $_POST["description"];
   
    $complaint_title = $category . " Complaint";

    // Image upload
    $image_path = NULL;

    if (isset($_FILES["complaint_image"]) && $_FILES["complaint_image"]["error"] == 0) {

        $upload_dir = "uploads/";

        // Create uploads folder if it doesn't exist
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $image_name = time() . "_" . basename($_FILES["complaint_image"]["name"]);

        $image_path = $upload_dir . $image_name;

        // Check image
        $check = getimagesize($_FILES["complaint_image"]["tmp_name"]);

        if ($check === false) {
            die("Please upload a valid image.");
        }

        // Allow only these image types
        $allowed_types = ["jpg", "jpeg", "png", "gif"];

        $extension = strtolower(
            pathinfo($_FILES["complaint_image"]["name"], PATHINFO_EXTENSION)
        );

        if (!in_array($extension, $allowed_types)) {
            die("Only JPG, JPEG, PNG and GIF images are allowed.");
        }

        // Move image to uploads folder
        if (!move_uploaded_file(
            $_FILES["complaint_image"]["tmp_name"],
            $image_path
        )) {
            die("Failed to upload image.");
        }
    }

    // Insert complaint into database
    $sql = "INSERT INTO complaints
            (name, contact_number, ward_area, service_category,
             complaint_title, complaint_description, complaint_image)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }

    $stmt->bind_param(
        "sssssss",
        $name,
        $mobile,
        $location,
        $category,
        $complaint_title,
        $description,
        $image_path
    );

    if ($stmt->execute()) {

        $complaint_id = $stmt->insert_id;

        echo "<h2>Complaint Submitted Successfully!</h2>";

        echo "<p>Your Complaint ID is: <b>"
             . $complaint_id .
             "</b></p>";

        if ($image_path != NULL) {
            echo "<p>Complaint image uploaded successfully.</p>";
        } else {
            echo "<p>No image was attached.</p>";
        }

        echo '<br><a href="index.php">Back to Home</a>';

    } else {

        echo "Error submitting complaint: " . $stmt->error;
    }

    $stmt->close();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Submit Complaint</title>
</head>
<body>

<h2>Submit a Complaint</h2>

<form method="POST">

    <label>Name:</label><br>
    <input type="text" name="name" required><br><br>

    <label>Complaint designation:</label><br>
    <textarea name="complaint_designation" rows="3" required></textarea><br><br>

    <label>Contact Number:</label><br>
    <input type="text" name="contact_number" required><br><br>

    <label>Email:</label><br>
    <input type="text" name="email" required><br><br>

    <label>Ward/Area:</label><br>
    <input type="text" name="ward_area" required><br><br>

    <label>Block:</label><br>
    <input type="text" name="block" required><br><br>

    <label>Complaint Title:</label><br>
    <input type="text" name="complaint_title" required><br><br>

    <label>Complaint Description:</label><br>
    <textarea name="complaint_description" rows="5" required></textarea><br><br>

    <button type="submit">Submit Complaint</button>

</form>

</body>
</html>