<?php
include_once "db.php";

$complaint = null;
$message = "";

/* =========================
   TRACK COMPLAINT
========================= */

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["track_complaint"])) {

    $complaint_id = trim($_POST["complaint_id"]);

    $sql = "SELECT * FROM complaints WHERE complaint_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $complaint_id);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        $complaint = $result->fetch_assoc();

    } else {

        $message = "Complaint ID not found. Please check your Complaint ID.";

    }

    $stmt->close();
}


/* =========================
   FEEDBACK & RATING
========================= */

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit_feedback"])) {

    $complaint_id = $_POST["complaint_id"];
    $feedback = trim($_POST["feedback"]);
    $rating = intval($_POST["satisfaction_rating"]);

    $sql = "UPDATE complaints
            SET feedback = ?, satisfaction_rating = ?
            WHERE complaint_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sis", $feedback, $rating, $complaint_id);

    if ($stmt->execute()) {

        $message = "Thank you! Your feedback has been submitted.";

        /* Get updated complaint */
        $sql2 = "SELECT * FROM complaints WHERE complaint_id = ?";

        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("s", $complaint_id);
        $stmt2->execute();

        $result2 = $stmt2->get_result();

        if ($result2->num_rows > 0) {
            $complaint = $result2->fetch_assoc();
        }

        $stmt2->close();

    } else {

        $message = "Unable to submit feedback.";

    }

    $stmt->close();
}

?>
<!DOCTYPE html>
<html>

<head>

    <title>Track Complaint</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;

            background: linear-gradient(
                135deg,
                #dff3ff,
                #f5faff,
                #e8f7f0
            );

            min-height: 100vh;
        }

        /* Main container */

        .container {
            width: 90%;
            max-width: 900px;
            margin: 40px auto;
        }

        /* Header */

        .header {
            background: #1769aa;
            color: white;
            padding: 25px;
            border-radius: 15px 15px 0 0;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .header h1 {
            margin: 0;
            font-size: 30px;
        }

        .header p {
            margin-top: 8px;
            margin-bottom: 0;
        }

        /* Tracking form */

        .track-box {
            background: white;
            padding: 30px;
            border-radius: 0 0 15px 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.12);
            margin-bottom: 25px;
        }

        .track-box label {
            font-weight: bold;
            color: #333;
        }

        .track-box input[type="text"] {
            width: 100%;
            padding: 13px;
            margin-top: 8px;
            border: 1px solid #bbb;
            border-radius: 8px;
            font-size: 16px;
        }

        .track-button {
            margin-top: 15px;
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 8px;
            background: #1769aa;
            color: white;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
        }

        .track-button:hover {
            background: #0d4f82;
        }

        /* Message */

        .message {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }

        /* Complaint details */

        .details-box {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.12);
        }

        .details-box h2 {
            text-align: center;
            color: #1769aa;
            margin-top: 0;
        }

        .detail-row {
            display: flex;
            border-bottom: 1px solid #ddd;
            padding: 14px 5px;
        }

        .detail-label {
            width: 30%;
            font-weight: bold;
            color: #444;
        }

        .detail-value {
            width: 70%;
            color: #222;
            word-wrap: break-word;
        }

        /* Status */

        .status {
            display: inline-block;
            padding: 8px 18px;
            border-radius: 20px;
            font-weight: bold;
        }

        .pending {
            background: #fff3cd;
            color: #856404;
        }

        .progress {
            background: #cfe2ff;
            color: #084298;
        }

        .resolved {
            background: #d1e7dd;
            color: #0f5132;
        }

        /* Flow section */

        .flow-box {
            margin-top: 25px;
            padding: 25px;
            background: #f8fbff;
            border-radius: 12px;
            border: 1px solid #d5e5f5;
        }

        .flow-box h3 {
            text-align: center;
            color: #1769aa;
        }

        .flow-step {
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
        }

        .step-status {
            background: #d9edf7;
            color: #31708f;
        }

        .step-delay {
            background: #fff0d9;
            color: #8a5a00;
        }

        .step-closed {
            background: #e1f5e8;
            color: #26733f;
        }

        /* Delay form */

        .delay-box {
            margin-top: 25px;
            padding: 25px;
            background: #fff8ed;
            border: 1px solid #f0d5a8;
            border-radius: 12px;
        }

        .delay-box h3 {
            color: #9a6200;
            margin-top: 0;
        }

        .form-label {
            display: block;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 7px;
        }

        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #bbb;
            border-radius: 7px;
            font-family: Arial, sans-serif;
            font-size: 15px;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        /* Feedback */

        .feedback-box {
            margin-top: 25px;
            padding: 25px;
            background: #eefaf1;
            border: 1px solid #b9dfc2;
            border-radius: 12px;
        }

        .feedback-box h3 {
            color: #26733f;
            margin-top: 0;
        }

        .submit-button {
            width: 100%;
            margin-top: 15px;
            padding: 13px;
            background: #198754;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .submit-button:hover {
            background: #146c43;
        }

        /* Closed */

        .closed-box {
            margin-top: 25px;
            padding: 25px;
            background: #e9f8ed;
            border: 1px solid
 #a8d5b3;
 border-radius: 12px;
            text-align: center;
        }

        .closed-box h3 {
            color: #198754;
        }

        .closed-icon {
            font-size: 45px;
        }

        /* Back */

        .back {
            text-align: center;
            margin-top: 25px;
        }

        .back a {
            text-decoration: none;
            color: #1769aa;
            font-weight: bold;
        }

        .back a:hover {
            text-decoration: underline;
        }

        @media(max-width: 650px) {

            .container {
                width: 95%;
                margin: 20px auto;
            }

            .detail-row {
                display: block;
            }

            .detail-label,
            .detail-value {
                width: 100%;
            }

            .detail-value {
                margin-top: 5px;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <!-- HEADER -->

    <div class="header">

        <h1>Complaint Status Tracking</h1>

        <p>Hospital Complaint Management System</p>

    </div>


    <!-- TRACK FORM -->

    <div class="track-box">

        <form method="POST">

            <input type="hidden" name="track_complaint" value="1">

            <label>Enter Complaint ID</label>

            <input
                type="text"
                name="complaint_id"
                placeholder="Enter your Complaint ID"
                required
            >

            <button type="submit" class="track-button">
                Track Complaint
            </button>

        </form>

    </div>


    <!-- MESSAGE -->

    <?php if ($message != "") { ?>

        <div class="message">

            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php } ?>


    <?php if ($complaint != null) { ?>


        <!-- COMPLAINT DETAILS -->

        <div class="details-box">

            <h2>Complaint Details</h2>


            <div class="detail-row">

                <div class="detail-label">
                    Complaint ID
                </div>

                <div class="detail-value">
                    <?php
                    echo htmlspecialchars(
                        $complaint["complaint_id"]
                    );
                    ?>
                </div>

            </div>
            <div class="detail-row">

                <div class="detail-label">
                    Name
                </div>

                <div class="detail-value">

                    <?php

                    if (isset($complaint["name"])) {

                        echo htmlspecialchars(
                            $complaint["name"]
                        );

                    } elseif (isset($complaint["name_designation"])) {

                        echo htmlspecialchars(
                            $complaint["name_designation"]
                        );

                    }

                    ?>

                </div>

            </div>


            <div class="detail-row">

                <div class="detail-label">
                    Department / Ward / Area
                </div>

                <div class="detail-value">

                    <?php

                    if (isset($complaint["department"])) {

                        echo htmlspecialchars(
                            $complaint["department"]
                        );

                    }

                    if (
                        isset($complaint["location"]) &&
                        $complaint["location"] != ""
                    ) {

                        echo " / " .
                            htmlspecialchars(
                                $complaint["location"]
                            );

                    }

                    ?>

                </div>

            </div>


            <div class="detail-row">

                <div class="detail-label">
                    Complaint Title
                </div>

                <div class="detail-value">

                    <?php

                    echo htmlspecialchars(
                        $complaint["complaint_title"] ?? ""
                    );

                    ?>

                </div>

            </div>
            <div class="detail-row">

                <div class="detail-label">
                    Description
                </div>

                <div class="detail-value">

                    <?php

                    echo nl2br(
                        htmlspecialchars(
                            $complaint["complaint_description"] ?? ""
                        )
                    );

                    ?>

                </div>

            </div>


            <!-- STATUS -->

            <div class="detail-row">

                <div class="detail-label">
                    Current Status
                </div>

                <div class="detail-value">

                    <?php

                    $status = $complaint["status"] ?? "Pending";

                    if ($status == "Resolved") {

                        echo '<span class="status resolved">
                                ✓ Resolved
                              </span>';

                    } elseif ($status == "In Progress") {

                        echo '<span class="status progress">
                                ⟳ In Progress
                              </span>';

                    } else {

                        echo '<span class="status pending">
                                ⏳ Pending
                              </span>';

                    }

                    ?>

                </div>

            </div>


            <!-- =========================
                 STATUS FLOW
            ========================= -->

            <div class="flow-box">

                <h3>Complaint Progress</h3>


                <div class="flow-step step-status">

                     Status Tracking

                    <br>

                    <?php echo htmlspecialchars($status); ?>

                </div>


                <?php if ($status == "Resolved") { ?>


                    <!-- YES PATH -->

                    <div class="flow-step step-closed">

                        ✓ YES —
 Complaint Resolved
 </div>


                    <div class="closed-box">

                        <div class="closed-icon">
                            ✓
                        </div>

                        <h3>
                             Complaint Closed
                        </h3>

                        <p>
                            Your complaint has been successfully
                            resolved and closed.
                        </p>

                    </div>


                    <!-- FEEDBACK -->

                    <div class="feedback-box">

                        <h3>
                             Feedback & Satisfaction Rating
                        </h3>

                        <?php

                        if (
                            isset($complaint["satisfaction_rating"]) &&
                            $complaint["satisfaction_rating"] != ""
                        ) {

                            echo "<p><strong>Your Rating:</strong> " .
                                htmlspecialchars(
                                    $complaint["satisfaction_rating"]
                                ) .
                                "/5</p>";

                            if (
                                isset($complaint["feedback"]) &&
                                $complaint["feedback"] != ""
                            ) {

                                echo "<p><strong>Your Feedback:</strong><br>" .
                                    nl2br(
                                        htmlspecialchars(
                                            $complaint["feedback"]
                                        )
                                    ) .
                                    "</p>";

                            }

                        } else {

                        ?>

                            <form method="POST">

                                <input
                                    type="hidden"
                                    name="submit_feedback"
                                    value="1"
                                >

                                <input
                                    type="hidden"
                                    name="complaint_id"
                                    value="<?php
                                    echo htmlspecialchars(
                                        $complaint["complaint_id"]
                                    );
                                    ?>"
                                >


                                <label class="form-label">
                                    Satisfaction Rating
                                </label>

                                <select
                                    name="satisfaction_rating"
                                    required
                                >

                                    <option value="">
                                        Select Rating
                                    </option>

                                    <option value="5">
                                        ★★★★★ - Excellent
                                    </option>

                                    <option value="4">
                                        ★★★★☆ - Very Good
                                    </option>

                                    <option value="3">
                                        ★★★☆☆ - Good
                                    </option>

                                    <option value="2">
                                        ★★☆☆☆ - Average
                                    </option>

                                    <option value="1">
                                        ★☆☆☆☆ - Poor
                                    </option>

                                </select>
                                <label class="form-label">
                                    Feedback
                                </label>

                                <textarea
                                    name="feedback"
                                    placeholder="Enter your feedback"
                                ></textarea>


                                <button
                                    type="submit"
                                    class="submit-button"
                                >

                                    Submit Feedback

                                </button>

                            </form>

                        <?php } ?>

                    </div>


                    <!-- MONTHLY REPORT -->

                    <div class="flow-step step-closed">

                         Monthly Reports

                    </div>


                <?php } else { ?>


                    <!-- NO PATH -->

                    <div class="flow-step step-delay">

                        ✕ NO — Complaint Not Resolved

                    </div>


                    <!-- DELAY REASON -->

                    <div class="delay-box">

                        <h3>
                             Reason for Delay
                        </h3>


                        <p>
                            The complaint is still being processed.
                            The following information explains the
                            current delay and expected resolution time.
                        </p>


                        <label class="form-label">
                            Reason for Delay
                        </label>

                        <div>

                            <?php

                            if (
                                isset($complaint["delay_reason"]) &&
                                $complaint["delay_reason"] != ""
                            ) {

                                echo nl2br(
                                    htmlspecialchars(
                                        $complaint["delay_reason"]
                                    )
                                );

                            } else {

                                echo "Reason for delay has not been updated yet.";

                            }

                            ?>

                        </div>


                        <label class="form-label">
                             Expected Time for Resolution (ETR)
                        </label>

                        <div>

                            <?php

                            if (
                                isset(
                                    $complaint[
                                        "expected_resolution_time"
                                    ]
                                ) &&
                                $complaint[
                                    "expected_resolution_time"
                                ] != ""
                            ) {

                                echo htmlspecialchars(
                                    $complaint[
                                        "expected_resolution_time"
                                    ]
                                );

                            } else {

                                echo "Expected resolution time has not been updated yet.";

                            }

                            ?>

                        </div>

                    </div>


                    <!-- CONTINUE TRACKING -->

                    <div class="flow-step step-status">

                        🔔  Notify Complainant & Continue Status Tracking

                    </div>


                    <div class="flow-step step-status">

                        🔄 Continue Status Tracking Until Resolved

                    </div>


                <?php } ?>


            </div>

        </div>


    <?php } ?>


    <!-- BACK -->

    <div class="back">

        <a href="index.php">
            ← Back to Home
        </a>

    </div>

</div>

</body>

</html>