<?php

session_start();
include_once "db.php";

if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $complaint_id = $_POST["complaint_id"];
    $status = $_POST["status"];

    $sql = "UPDATE complaints SET status = ? WHERE complaint_id = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ss", $status, $complaint_id);

    if ($stmt->execute()) {
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "Error updating status: " . $stmt->error;
    }
}
?>